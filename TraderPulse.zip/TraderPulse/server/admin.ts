import { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

interface AuthenticatedRequest extends Request {
  user?: { 
    id?: number;
    firebaseUid?: string; 
    email?: string;
    username?: string;
    displayName?: string;
    isAdmin?: boolean;
  };
}

// Middleware to check if a user is an admin
export const adminMiddleware = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  if (!req.user.id) {
    return res.status(401).json({ message: "Invalid user session" });
  }
  
  try {
    const user = await storage.getUser(req.user.id);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }
    
    next();
  } catch (error) {
    console.error("Admin middleware error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};

export function setupAdminRoutes(app: Express, authMiddleware: any) {
  // Get all users (admin only)
  app.get("/api/users", authMiddleware, adminMiddleware, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Create a new user (admin only)
  app.post("/api/users", authMiddleware, adminMiddleware, async (req: AuthenticatedRequest, res: Response) => {
    try {
      // Validate user input
      const parsedInput = insertUserSchema.safeParse(req.body);
      if (!parsedInput.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: parsedInput.error.errors 
        });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      // Check if email already exists
      const users = await storage.getAllUsers();
      const emailExists = users.some(user => user.email === req.body.email);
      if (emailExists) {
        return res.status(409).json({ message: "Email already exists" });
      }
      
      // Create user
      const newUser = await storage.createUser(req.body);
      res.status(201).json(newUser);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  // Update a user (admin only)
  app.patch("/api/users/:id", authMiddleware, adminMiddleware, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get the user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Validate the update data
      const updateSchema = z.object({
        isAdmin: z.boolean().optional(),
        isActive: z.boolean().optional(),
        displayName: z.string().optional()
      });
      
      const parseResult = updateSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ 
          message: "Invalid update data", 
          errors: parseResult.error.errors 
        });
      }
      
      // Update the user
      const updatedUser = await storage.updateUser(userId, req.body);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });
}