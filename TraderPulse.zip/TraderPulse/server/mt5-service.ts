import { Express, Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { 
  Mt5AccountData, 
  Mt5Position, 
  insertMt5AccountSchema, 
  insertMt5AccountAlertSchema
} from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { createCipheriv, createDecipheriv, randomBytes } from "crypto";

// Encryption helpers for MT5 credentials
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || "default_encryption_key_32_bytes_long"; // 32 bytes
const IV_LENGTH = 16; // 16 bytes for AES

function encrypt(text: string): string {
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return `${iv.toString('hex')}:${encrypted}`;
}

function decrypt(text: string): string {
  const [ivHex, encryptedText] = text.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const decipher = createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
  let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

// Authentication will be handled by the middleware passed from auth.ts
// We'll define a type for the authenticated request with user info
interface AuthenticatedRequest extends Request {
  user?: { 
    id?: number;
    firebaseUid?: string; 
    email?: string;
    username?: string;
    displayName?: string;
  };
}

// Mock MT5 account data generator for demonstration
const generateMockMt5Data = (accountData: { 
  accountNumber: string; 
  accountName: string; 
  brokerName: string; 
}): Mt5AccountData => {
  // This is a placeholder for actual MT5 API integration
  // In production, this would call the actual MT5 API client
  
  const balance = Math.random() * 100000 + 10000;
  const equity = balance + (Math.random() * 10000 - 5000);
  const margin = equity * (Math.random() * 0.3 + 0.1);
  const freeMargin = equity - margin;
  const marginLevel = (equity / margin) * 100;
  const profit = equity - balance;
  const positions = Math.floor(Math.random() * 15);
  
  let status: "healthy" | "warning" | "danger" = "healthy";
  if (marginLevel < 200) status = "warning";
  if (marginLevel < 100) status = "danger";
  
  return {
    accountNumber: accountData.accountNumber,
    accountName: accountData.accountName,
    brokerName: accountData.brokerName,
    balance,
    equity,
    margin,
    freeMargin,
    marginLevel,
    profit,
    positions,
    lastUpdated: new Date().toISOString(),
    status
  };
};

// Mock MT5 positions generator for demonstration
const generateMockPositions = (accountsData: Mt5AccountData[]): Mt5Position[] => {
  // This is a placeholder for actual MT5 API integration
  // In production, this would call the actual MT5 API client
  
  const positions: Mt5Position[] = [];
  const symbols = ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD", "US30", "BTCUSD"];
  
  accountsData.forEach(account => {
    const numPositions = Math.min(account.positions, 5); // Limit to 5 positions per account for demo
    
    for (let i = 0; i < numPositions; i++) {
      const symbol = symbols[Math.floor(Math.random() * symbols.length)];
      const type = Math.random() > 0.5 ? "BUY" : "SELL";
      const volume = Math.random() * 2 + 0.1;
      
      let openPrice, currentPrice;
      if (symbol === "XAUUSD") {
        openPrice = Math.random() * 100 + 1900;
        currentPrice = openPrice + (Math.random() * 40 - 20);
      } else if (symbol === "US30") {
        openPrice = Math.random() * 1000 + 35000;
        currentPrice = openPrice + (Math.random() * 500 - 250);
      } else if (symbol === "BTCUSD") {
        openPrice = Math.random() * 5000 + 35000;
        currentPrice = openPrice + (Math.random() * 2000 - 1000);
      } else {
        openPrice = Math.random() * 0.1 + 1.0;
        currentPrice = openPrice + (Math.random() * 0.02 - 0.01);
      }
      
      const profit = type === "BUY" 
        ? (currentPrice - openPrice) * volume * (symbol === "XAUUSD" ? 100 : symbol === "US30" ? 5 : symbol === "BTCUSD" ? 10 : 100000)
        : (openPrice - currentPrice) * volume * (symbol === "XAUUSD" ? 100 : symbol === "US30" ? 5 : symbol === "BTCUSD" ? 10 : 100000);
      
      const profitPercent = (profit / (openPrice * volume * (symbol === "XAUUSD" ? 100 : symbol === "US30" ? 5 : symbol === "BTCUSD" ? 10 : 100000))) * 100;
      
      positions.push({
        accountNumber: account.accountNumber,
        accountName: account.accountName,
        symbol,
        type,
        volume,
        openPrice,
        currentPrice,
        profit,
        profitPercent,
        ticket: Math.floor(Math.random() * 1000000)
      });
    }
  });
  
  return positions;
};

// getAllUsers method is now implemented directly in the MemStorage class

if (!storage.getMt5Accounts) {
  // @ts-ignore - Adding methods for development
  storage.getMt5Accounts = async function(userId: number) {
    // Simulate getting user's MT5 accounts
    return [
      {
        id: 1,
        userId,
        accountNumber: "123456789",
        accountName: "Demo Account",
        brokerName: "Demo Broker",
        credentials: encrypt("demo:demo"),
      },
      {
        id: 2,
        userId,
        accountNumber: "987654321",
        accountName: "VIP Account",
        brokerName: "Premium Broker",
        credentials: encrypt("demo:demo"),
      }
    ];
  };
}

if (!storage.createMt5Account) {
  // @ts-ignore - Adding methods for development
  storage.createMt5Account = async function(account: any) {
    return {
      id: Math.floor(Math.random() * 1000),
      ...account
    };
  };
}

if (!storage.updateMt5Account) {
  // @ts-ignore - Adding methods for development
  storage.updateMt5Account = async function(id: number, data: any) {
    return {
      id,
      ...data
    };
  };
}

if (!storage.deleteMt5Account) {
  // @ts-ignore - Adding methods for development
  storage.deleteMt5Account = async function(id: number) {
    return true;
  };
}

if (!storage.getMt5Alerts) {
  // @ts-ignore - Adding methods for development
  storage.getMt5Alerts = async function(userId: number) {
    return [
      {
        id: 1,
        userId,
        accountNumber: "123456789",
        type: "EQUITY_BELOW",
        threshold: 10000,
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 2,
        userId,
        accountNumber: "987654321",
        type: "MARGIN_ABOVE",
        threshold: 50,
        isActive: false,
        createdAt: new Date().toISOString()
      }
    ];
  };
}

if (!storage.createMt5Alert) {
  // @ts-ignore - Adding methods for development
  storage.createMt5Alert = async function(alert: any) {
    return {
      id: Math.floor(Math.random() * 1000),
      ...alert,
      createdAt: new Date().toISOString()
    };
  };
}

if (!storage.updateMt5Alert) {
  // @ts-ignore - Adding methods for development
  storage.updateMt5Alert = async function(id: number, data: any) {
    return {
      id,
      ...data
    };
  };
}

if (!storage.deleteMt5Alert) {
  // @ts-ignore - Adding methods for development
  storage.deleteMt5Alert = async function(id: number) {
    return true;
  };
}

export function setupMt5Routes(app: Express, authMiddleware: (req: AuthenticatedRequest, res: Response, next: NextFunction) => void) {
  // Get MT5 accounts for user, with optional broker filter
  app.get("/api/mt5-accounts", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get accounts from storage
      const accounts = await storage.getMt5Accounts(user.id);
      
      // Filter by broker if broker query parameter is provided
      let filteredAccounts = accounts;
      const brokerQuery = req.query.broker;
      if (brokerQuery && typeof brokerQuery === 'string') {
        // @ts-ignore - Runtime check
        filteredAccounts = accounts.filter((account: any) => 
          account.brokerName.toLowerCase() === brokerQuery.toLowerCase()
        );
      }
      
      // Generate real-time data for each account
      // @ts-ignore - Runtime check
      const accountsWithData = filteredAccounts.map((account: any) => 
        generateMockMt5Data({
          accountNumber: account.accountNumber,
          accountName: account.accountName,
          brokerName: account.brokerName
        })
      );
      
      res.json(accountsWithData);
    } catch (error) {
      console.error("Get MT5 accounts error:", error);
      res.status(500).json({ message: "Failed to get MT5 accounts" });
    }
  });
  
  // Get available brokers for user
  app.get("/api/mt5-brokers", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get accounts from storage
      const accounts = await storage.getMt5Accounts(user.id);
      
      // Extract unique broker names
      // @ts-ignore - Runtime check
      const brokers = [...new Set(accounts.map((account: any) => account.brokerName))];
      
      res.json(brokers);
    } catch (error) {
      console.error("Get MT5 brokers error:", error);
      res.status(500).json({ message: "Failed to get MT5 brokers" });
    }
  });

  // Create MT5 account
  app.post("/api/mt5-accounts", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      // Validate request body
      const accountData = insertMt5AccountSchema.parse(req.body);
      
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Encrypt credentials
      const encryptedCredentials = encrypt(accountData.credentials);
      
      // Create account
      const account = await storage.createMt5Account({
        ...accountData,
        userId: user.id,
        credentials: encryptedCredentials
      });
      
      res.status(201).json(account);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Create MT5 account error:", error);
      res.status(500).json({ message: "Failed to create MT5 account" });
    }
  });

  // Update MT5 account
  app.patch("/api/mt5-accounts/:accountNumber", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const { accountNumber } = req.params;
      
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get account
      const accounts = await storage.getMt5Accounts(user.id);
      // @ts-ignore - Runtime check
      const account = accounts.find((a: any) => a.accountNumber === accountNumber);
      
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      // Process update data
      const updateData: any = { ...req.body };
      
      // If password is provided, encrypt it
      if (updateData.password) {
        updateData.credentials = encrypt(updateData.password);
        delete updateData.password;
      }
      
      // Update account
      const updatedAccount = await storage.updateMt5Account(account.id, updateData);
      
      res.json(updatedAccount);
    } catch (error) {
      console.error("Update MT5 account error:", error);
      res.status(500).json({ message: "Failed to update MT5 account" });
    }
  });

  // Delete MT5 account
  app.delete("/api/mt5-accounts/:accountNumber", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const { accountNumber } = req.params;
      
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get account
      const accounts = await storage.getMt5Accounts(user.id);
      // @ts-ignore - Runtime check
      const account = accounts.find((a: any) => a.accountNumber === accountNumber);
      
      if (!account) {
        return res.status(404).json({ message: "Account not found" });
      }
      
      // Delete account
      await storage.deleteMt5Account(account.id);
      
      res.status(204).send();
    } catch (error) {
      console.error("Delete MT5 account error:", error);
      res.status(500).json({ message: "Failed to delete MT5 account" });
    }
  });

  // Get MT5 positions with optional broker filter
  app.get("/api/mt5-positions", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get accounts
      const accounts = await storage.getMt5Accounts(user.id);
      
      // Filter by broker if broker query parameter is provided
      let filteredAccounts = accounts;
      const brokerQuery = req.query.broker;
      if (brokerQuery && typeof brokerQuery === 'string') {
        // @ts-ignore - Runtime check
        filteredAccounts = accounts.filter((account: any) => 
          account.brokerName.toLowerCase() === brokerQuery.toLowerCase()
        );
      }
      
      // Generate account data
      // @ts-ignore - Runtime check
      const accountsWithData = filteredAccounts.map((account: any) => 
        generateMockMt5Data({
          accountNumber: account.accountNumber,
          accountName: account.accountName,
          brokerName: account.brokerName
        })
      );
      
      // Generate positions
      const positions = generateMockPositions(accountsWithData);
      
      res.json(positions);
    } catch (error) {
      console.error("Get MT5 positions error:", error);
      res.status(500).json({ message: "Failed to get MT5 positions" });
    }
  });

  // Get MT5 alerts
  app.get("/api/mt5-alerts", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get alerts
      const alerts = await storage.getMt5Alerts(user.id);
      
      res.json(alerts);
    } catch (error) {
      console.error("Get MT5 alerts error:", error);
      res.status(500).json({ message: "Failed to get MT5 alerts" });
    }
  });

  // Get active MT5 alerts
  app.get("/api/mt5-alerts/active", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get alerts
      const alerts = await storage.getMt5Alerts(user.id);
      
      // Filter active alerts
      // @ts-ignore - Runtime check
      const activeAlerts = alerts.filter((alert: any) => alert.isActive);
      
      res.json(activeAlerts);
    } catch (error) {
      console.error("Get active MT5 alerts error:", error);
      res.status(500).json({ message: "Failed to get active MT5 alerts" });
    }
  });

  // Create MT5 alert
  app.post("/api/mt5-alerts", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      // Validate request body
      const alertData = insertMt5AccountAlertSchema.parse(req.body);
      
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Create alert
      const alert = await storage.createMt5Alert({
        ...alertData,
        userId: user.id
      });
      
      res.status(201).json(alert);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Create MT5 alert error:", error);
      res.status(500).json({ message: "Failed to create MT5 alert" });
    }
  });

  // Update MT5 alert
  app.patch("/api/mt5-alerts/:id", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const alertId = parseInt(req.params.id);
      
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get alert
      const alerts = await storage.getMt5Alerts(user.id);
      // @ts-ignore - Runtime check
      const alert = alerts.find((a: any) => a.id === alertId);
      
      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      // Update alert
      const updatedAlert = await storage.updateMt5Alert(alertId, req.body);
      
      res.json(updatedAlert);
    } catch (error) {
      console.error("Update MT5 alert error:", error);
      res.status(500).json({ message: "Failed to update MT5 alert" });
    }
  });

  // Toggle MT5 alert status
  app.patch("/api/mt5-alerts/:id/toggle", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const alertId = parseInt(req.params.id);
      const { isActive } = req.body;
      
      if (typeof isActive !== 'boolean') {
        return res.status(400).json({ message: "isActive must be a boolean" });
      }
      
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get alert
      const alerts = await storage.getMt5Alerts(user.id);
      // @ts-ignore - Runtime check
      const alert = alerts.find((a: any) => a.id === alertId);
      
      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      // Update alert status
      const updatedAlert = await storage.updateMt5Alert(alertId, { isActive });
      
      res.json(updatedAlert);
    } catch (error) {
      console.error("Toggle MT5 alert status error:", error);
      res.status(500).json({ message: "Failed to toggle MT5 alert status" });
    }
  });

  // Delete MT5 alert
  app.delete("/api/mt5-alerts/:id", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const alertId = parseInt(req.params.id);
      
      // Find user by email
      const users = await storage.getAllUsers();
      // @ts-ignore - Runtime check
      const user = users.find((u: any) => u.email === req.user?.email);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get alert
      const alerts = await storage.getMt5Alerts(user.id);
      // @ts-ignore - Runtime check
      const alert = alerts.find((a: any) => a.id === alertId);
      
      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      // Delete alert
      await storage.deleteMt5Alert(alertId);
      
      res.status(204).send();
    } catch (error) {
      console.error("Delete MT5 alert error:", error);
      res.status(500).json({ message: "Failed to delete MT5 alert" });
    }
  });
}
