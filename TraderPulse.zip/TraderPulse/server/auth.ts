import { Express, Request, Response, NextFunction } from "express";
import { auth as firebaseAdminAuth } from "./firebase-admin";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";

// We'll use the imported firebaseAdminAuth

const scryptAsync = promisify(scrypt);

// We'll use this flag to determine if we're using Firebase auth or our simple auth
const useFirebaseAuth = process.env.USE_FIREBASE_AUTH === 'true';

// Setup SESSION_SECRET environment variable 
const SESSION_SECRET = process.env.SESSION_SECRET || randomBytes(32).toString('hex');

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Enhanced type for request with user
interface AuthenticatedRequest extends Request {
  user?: { 
    id?: number;
    firebaseUid?: string; 
    email?: string;
    username?: string;
    displayName?: string | null;
    createdAt?: Date | null;
    password?: string;
  };
}

// Type for Firebase token
interface DecodedIdToken {
  uid: string;
  email: string;
  name?: string;
}

// Auth middleware that supports both Firebase and our session auth
const authMiddleware = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  // For session-based authentication
  if (req.isAuthenticated()) {
    return next();
  }
  
  try {
    // Check for auth header (for Firebase or API token authentication)
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return res.status(401).json({ message: "Unauthorized - Authentication required" });
    }
    
    // For development, allow a simple pass-through mode when Firebase is not configured
    // In production, this would use real Firebase authentication
    if (authHeader.startsWith('Bearer ')) {
      const token = authHeader.split('Bearer ')[1];
      
      try {
        // @ts-ignore - Firebase auth might be a mock in development mode
        const decodedToken: DecodedIdToken = await firebaseAdminAuth.verifyIdToken(token);
        
        // Get user from storage or create one if not exists
        let user = await findOrCreateUserFromFirebase(decodedToken);
        req.user = user;
        return next();
      } catch (error) {
        console.warn("Auth token verification failed:", error);
        return res.status(401).json({ message: "Invalid authentication token" });
      }
    } else if (authHeader.startsWith('Basic ')) {
      // Simple auth for development - email:id format
      const base64Credentials = authHeader.split(' ')[1];
      const credentials = Buffer.from(base64Credentials, 'base64').toString('utf8');
      const [email, userId] = credentials.split(':');
      
      if (!email || !userId) {
        return res.status(401).json({ message: "Invalid basic auth format" });
      }
      
      // Find user by email and id
      const user = await storage.getUser(parseInt(userId));
      if (!user || user.email !== email) {
        return res.status(401).json({ message: "User not found or mismatch" });
      }
      
      req.user = user;
      return next();
    }
    
    return res.status(401).json({ message: "Unsupported authentication method" });
  } catch (error) {
    console.error("Auth middleware error:", error);
    return res.status(500).json({ message: "Authentication error" });
  }
};

// Helper function to find or create user from Firebase auth
async function findOrCreateUserFromFirebase(decodedToken: DecodedIdToken) {
  try {
    // For development mode, always return a mocked user
    if (!useFirebaseAuth) {
      return { 
        id: 1, 
        email: decodedToken.email || "user@example.com",
        username: "user1",
        displayName: "Demo User" 
      };
    }
    
    // First try to find user by email
    const users = await storage.getAllUsers();
    let user = users.find((u) => u.email === decodedToken.email);
    
    // If not found, create a new user
    if (!user) {
      // Generate random username from email
      const username = `user_${Math.floor(Math.random() * 10000)}`;
      
      // Create new user
      user = await storage.createUser({
        username,
        email: decodedToken.email,
        password: await hashPassword(randomBytes(16).toString('hex')),
        displayName: decodedToken.name || username,
      });
    }
    
    // Remove password before returning
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  } catch (error) {
    console.error("Error finding/creating user from Firebase:", error);
    // Return a minimal user object to prevent failures
    return { 
      id: 1,
      email: decodedToken.email || "user@example.com" 
    };
  }
}

export function setupAuth(app: Express) {
  console.log(`Auth system running in ${useFirebaseAuth ? 'Firebase' : 'development'} mode`);

  // Setup passport with local strategy
  passport.use(new LocalStrategy(
    { usernameField: 'email' },
    async (email, password, done) => {
      try {
        console.log(`[AUTH] Attempting login for user: ${email}`);
        
        // Find user by email
        const users = await storage.getAllUsers();
        const user = users.find((u) => u.email === email);
        
        if (!user) {
          console.log(`[AUTH] User not found: ${email}`);
          return done(null, false, { message: 'User not found' });
        }
        
        // For admin login or demo accounts with direct password match (not secure but for demo purposes)
        if (email === 'shahmeetk@gmail.com' && password === 'Smk@10290') {
          console.log(`[AUTH] Admin login successful`);
          return done(null, user);
        }
        
        // In development mode, use a more lenient password check
        const passwordMatch = !useFirebaseAuth || 
                              password === user.password || 
                              await comparePasswords(password, user.password);
        
        if (passwordMatch) {
          console.log(`[AUTH] Login successful for user: ${email}`);
          return done(null, user);
        }
        
        console.log(`[AUTH] Password verification failed for user: ${email}`);
        return done(null, false, { message: 'Incorrect password' });
      } catch (error) {
        console.error(`[AUTH] Login error for ${email}:`, error);
        return done(error);
      }
    }
  ));

  // Serialize/deserialize user for session
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      
      // Remove password before returning
      const { password: _, ...userWithoutPassword } = user;
      done(null, userWithoutPassword);
    } catch (error) {
      done(error);
    }
  });

  // Setup session
  app.use(session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Register a new user
  app.post("/api/register", async (req, res) => {
    try {
      const { username, email, password, displayName, isAdmin = false, isActive = false } = req.body;
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Create a new user with hashed password
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        displayName: displayName || username,
        isAdmin,
        isActive,
      });
      
      // Only log in the user if they're marked as active
      if (user.isActive) {
        req.login(user, (err) => {
          if (err) {
            return res.status(500).json({ message: "Error during login after registration" });
          }
          
          // Return the user without password
          const { password: _, ...userWithoutPassword } = user;
          return res.status(201).json(userWithoutPassword);
        });
      } else {
        // Return the user without password but don't log them in
        const { password: _, ...userWithoutPassword } = user;
        return res.status(201).json({
          ...userWithoutPassword,
          pendingApproval: true,
        });
      }
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to register user" });
    }
  });

  // Login with email/password
  app.post("/api/login", (req, res, next) => {
    passport.authenticate('local', (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || 'Authentication failed' });
      }
      
      // Check if the user is active
      if (!user.isActive) {
        return res.status(403).json({ 
          message: 'Your account is pending approval. Please contact an administrator.',
          pendingApproval: true 
        });
      }
      
      req.login(user, (err: any) => {
        if (err) {
          return next(err);
        }
        
        // Return the user without password
        const { password: _, ...userWithoutPassword } = user;
        return res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  // Logout
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) {
        return next(err);
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.status(200).json(req.user);
  });
  
  // Expose the auth middleware for other routes to use
  return { authMiddleware };
}
