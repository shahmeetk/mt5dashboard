import { users, mt5Accounts, mt5AccountAlerts, type User, type InsertUser, type Mt5Account, type InsertMt5Account, type Mt5AccountAlert, type InsertMt5AccountAlert } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User>;
  
  // MT5 account methods
  getMt5Accounts(userId: number): Promise<Mt5Account[]>;
  createMt5Account(account: InsertMt5Account & { userId: number }): Promise<Mt5Account>;
  updateMt5Account(id: number, data: Partial<InsertMt5Account>): Promise<Mt5Account>;
  deleteMt5Account(id: number): Promise<boolean>;
  
  // MT5 alert methods
  getMt5Alerts(userId: number): Promise<Mt5AccountAlert[]>;
  createMt5Alert(alert: InsertMt5AccountAlert & { userId: number }): Promise<Mt5AccountAlert>;
  updateMt5Alert(id: number, data: Partial<InsertMt5AccountAlert>): Promise<Mt5AccountAlert>;
  deleteMt5Alert(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: session.Store;
}

// Database implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    const PostgresSessionStore = connectPg(session);
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
    
    // Create predefined allowed users
    const allowedUsers = [
      {
        username: "trader1",
        email: "trader1@example.com",
        password: "trader123", // Will be hashed by auth system
        displayName: "John Trader",
        isAdmin: false,
        isActive: true
      },
      {
        username: "trader2",
        email: "trader2@example.com",
        password: "trader456",
        displayName: "Jane Investor",
        isAdmin: false,
        isActive: true
      },
      {
        username: "admin",
        email: "shahmeetk@gmail.com",
        password: "Smk@10290",
        displayName: "Admin User",
        isAdmin: true,
        isActive: true
      }
    ];
    
    // Create all allowed users if they don't exist
    Promise.all(
      allowedUsers.map(async (userData) => {
        const existingUser = await this.getUserByUsername(userData.username);
        if (!existingUser) {
          await this.createUser(userData);
          console.log(`Created user: ${userData.username}`);
        }
      })
    ).catch(console.error);
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        displayName: insertUser.displayName || null,
        isAdmin: insertUser.isAdmin || false,
        isActive: insertUser.isActive !== undefined ? insertUser.isActive : true
      })
      .returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  async updateUser(id: number, data: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return user;
  }
  
  // MT5 account methods
  async getMt5Accounts(userId: number): Promise<Mt5Account[]> {
    return db.select().from(mt5Accounts).where(eq(mt5Accounts.userId, userId));
  }
  
  async createMt5Account(account: InsertMt5Account & { userId: number }): Promise<Mt5Account> {
    const [newAccount] = await db
      .insert(mt5Accounts)
      .values(account)
      .returning();
    return newAccount;
  }
  
  async updateMt5Account(id: number, data: Partial<InsertMt5Account>): Promise<Mt5Account> {
    const [updatedAccount] = await db
      .update(mt5Accounts)
      .set(data)
      .where(eq(mt5Accounts.id, id))
      .returning();
    return updatedAccount;
  }
  
  async deleteMt5Account(id: number): Promise<boolean> {
    await db.delete(mt5Accounts).where(eq(mt5Accounts.id, id));
    return true;
  }
  
  // MT5 alert methods
  async getMt5Alerts(userId: number): Promise<Mt5AccountAlert[]> {
    return db.select().from(mt5AccountAlerts).where(eq(mt5AccountAlerts.userId, userId));
  }
  
  async createMt5Alert(alert: InsertMt5AccountAlert & { userId: number }): Promise<Mt5AccountAlert> {
    const [newAlert] = await db
      .insert(mt5AccountAlerts)
      .values({
        ...alert,
        accountId: alert.accountId || null,
        description: alert.description || null,
        timeWindow: alert.timeWindow || null,
      })
      .returning();
    return newAlert;
  }
  
  async updateMt5Alert(id: number, data: Partial<InsertMt5AccountAlert>): Promise<Mt5AccountAlert> {
    const [updatedAlert] = await db
      .update(mt5AccountAlerts)
      .set(data)
      .where(eq(mt5AccountAlerts.id, id))
      .returning();
    return updatedAlert;
  }
  
  async deleteMt5Alert(id: number): Promise<boolean> {
    await db.delete(mt5AccountAlerts).where(eq(mt5AccountAlerts.id, id));
    return true;
  }
}

// Memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private mt5Accounts: Map<number, Mt5Account>;
  private mt5Alerts: Map<number, Mt5AccountAlert>;
  currentId: number;
  sessionStore: session.Store;
  
  constructor() {
    this.users = new Map();
    this.mt5Accounts = new Map();
    this.mt5Alerts = new Map();
    this.currentId = 1;
    
    // Initialize session store
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Create predefined allowed users
    const allowedUsers = [
      {
        username: "trader1",
        email: "trader1@example.com",
        password: "trader123", // Will be hashed by auth system
        displayName: "John Trader",
        isAdmin: false,
        isActive: true
      },
      {
        username: "trader2",
        email: "trader2@example.com",
        password: "trader456",
        displayName: "Jane Investor",
        isAdmin: false,
        isActive: true
      },
      {
        username: "admin",
        email: "shahmeetk@gmail.com",
        password: "Smk@10290",
        displayName: "Admin User",
        isAdmin: true,
        isActive: true
      }
    ];
    
    // Create all allowed users
    allowedUsers.forEach(userData => {
      this.createUser(userData).catch(console.error);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
      displayName: insertUser.displayName || null,
      isAdmin: insertUser.isAdmin || false,
      isActive: insertUser.isActive !== undefined ? insertUser.isActive : true
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, data: Partial<InsertUser>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    const updatedUser = {
      ...user,
      ...data,
      displayName: data.displayName !== undefined ? data.displayName : user.displayName
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // MT5 account methods
  async getMt5Accounts(userId: number): Promise<Mt5Account[]> {
    return Array.from(this.mt5Accounts.values()).filter(
      (account) => account.userId === userId
    );
  }
  
  async createMt5Account(account: InsertMt5Account & { userId: number }): Promise<Mt5Account> {
    const id = this.currentId++;
    const newAccount: Mt5Account = {
      ...account,
      id,
      isActive: true,
      createdAt: new Date()
    };
    this.mt5Accounts.set(id, newAccount);
    return newAccount;
  }
  
  async updateMt5Account(id: number, data: Partial<InsertMt5Account>): Promise<Mt5Account> {
    const account = this.mt5Accounts.get(id);
    if (!account) {
      throw new Error(`MT5 account with ID ${id} not found`);
    }
    
    const updatedAccount = {
      ...account,
      ...data
    };
    this.mt5Accounts.set(id, updatedAccount);
    return updatedAccount;
  }
  
  async deleteMt5Account(id: number): Promise<boolean> {
    return this.mt5Accounts.delete(id);
  }
  
  // MT5 alert methods
  async getMt5Alerts(userId: number): Promise<Mt5AccountAlert[]> {
    return Array.from(this.mt5Alerts.values()).filter(
      (alert) => alert.userId === userId
    );
  }
  
  async createMt5Alert(alert: InsertMt5AccountAlert & { userId: number }): Promise<Mt5AccountAlert> {
    const id = this.currentId++;
    
    // Create a properly typed alert object
    const newAlert: Mt5AccountAlert = {
      id,
      userId: alert.userId,
      name: alert.name,
      alertType: alert.alertType,
      threshold: alert.threshold,
      isActive: alert.isActive === undefined ? true : alert.isActive,
      accountId: alert.accountId || null,
      description: alert.description || null,
      notificationMethods: alert.notificationMethods || [],
      timeWindow: alert.timeWindow || null,
      lastTriggered: null,
      createdAt: new Date()
    };
    
    this.mt5Alerts.set(id, newAlert);
    return newAlert;
  }
  
  async updateMt5Alert(id: number, data: Partial<InsertMt5AccountAlert>): Promise<Mt5AccountAlert> {
    const alert = this.mt5Alerts.get(id);
    if (!alert) {
      throw new Error(`MT5 alert with ID ${id} not found`);
    }
    
    const updatedAlert = {
      ...alert,
      ...data
    };
    this.mt5Alerts.set(id, updatedAlert);
    return updatedAlert;
  }
  
  async deleteMt5Alert(id: number): Promise<boolean> {
    return this.mt5Alerts.delete(id);
  }
}

// Conditionally use the appropriate storage implementation
// If DATABASE_URL is present, use DatabaseStorage, otherwise use MemStorage
const useDatabase = !!process.env.DATABASE_URL;
export const storage = useDatabase 
  ? new DatabaseStorage()
  : new MemStorage();