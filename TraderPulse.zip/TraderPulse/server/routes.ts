import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { setupMt5Routes } from "./mt5-service";
import { setupAdminRoutes } from "./admin";
import { storage } from "./storage";
import { startMt5UpdateService } from "./mt5-connector";
import { log } from "./vite";
import { WebSocketServer } from 'ws';

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes and get the auth middleware
  const { authMiddleware } = setupAuth(app);
  
  // Setup MT5 account routes with auth middleware
  setupMt5Routes(app, authMiddleware);
  
  // Setup admin routes with auth middleware
  setupAdminRoutes(app, authMiddleware);
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Start the MT5 real-time data service
  try {
    // Start Socket.io service for real-time MT5 data
    startMt5UpdateService(httpServer);
    
    // Also setup WebSocket server for direct connection
    const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
    
    wss.on('connection', (ws) => {
      log('WebSocket client connected', 'mt5-ws');
      
      ws.on('message', (message) => {
        log(`Received message: ${message}`, 'mt5-ws');
      });
      
      ws.on('close', () => {
        log('WebSocket client disconnected', 'mt5-ws');
      });
    });
    
    log('MT5 real-time data services started', 'mt5-connector');
  } catch (error) {
    log(`Error starting MT5 services: ${error}`, 'mt5-connector');
  }

  return httpServer;
}
