import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
import { getDatabase } from "firebase-admin/database";
import * as fs from "fs";
import * as path from "path";

let app;
let auth;
let firestore;
let database;

interface DecodedIdToken {
  uid: string;
  email: string;
}

class MockAuth {
  async verifyIdToken(token: string): Promise<DecodedIdToken> {
    // For demo purposes, support predefind users
    console.log("MOCK AUTH: Verifying token", token);
    
    // Check if token is for our admin user
    if (token === "admin-uid-123") {
      return { 
        uid: "admin-uid-123", 
        email: "shahmeetk@gmail.com" 
      };
    }
    
    // For other users, decode from token if possible
    if (token && token.includes(':')) {
      try {
        const [uid, email] = token.split(':');
        if (uid && email) {
          return { uid, email };
        }
      } catch (err) {
        console.error("Error parsing token:", err);
      }
    }
    
    // Default mock user as fallback
    return { uid: "user-" + Date.now(), email: "user@example.com" };
  }
}

// Try to load service account key file
try {
  const serviceAccountPath = path.join(process.cwd(), 'serviceAccountKey.json');
  
  if (fs.existsSync(serviceAccountPath)) {
    // Initialize Firebase Admin with service account
    const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
    
    app = initializeApp({
      credential: cert(serviceAccount),
      databaseURL: "https://mt5monitor-01-default-rtdb.firebaseio.com"
    });
    
    // Export Firebase Admin services
    auth = getAuth(app);
    firestore = getFirestore(app);
    database = getDatabase(app);
    
    console.log("Firebase Admin SDK initialized with service account");
  } else {
    console.log("Service account file not found. Using mock implementations.");
    app = null;
    auth = new MockAuth();
    firestore = null;
    database = null;
  }
} catch (error) {
  console.error("Error initializing Firebase Admin:", error);
  app = null;
  auth = new MockAuth();
  firestore = null;
  database = null;
}

export { auth, firestore, database };
export default app;
