import { createContext, ReactNode, useContext, useState, useCallback } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { InsertUser, User as SelectUser } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Simple auth context type
type AuthContextType = {
  user: SelectUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SelectUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SelectUser, Error, InsertUser>;
};

// Login data type for mutations
type LoginData = {
  email: string;
  password: string;
};

// Create the context with default values to avoid circular dependencies
const defaultMutationState = {
  mutate: () => {},
  isPending: false,
  isSuccess: false,
  isError: false,
  error: null,
  reset: () => {},
} as any;

const defaultContext: AuthContextType = {
  user: null,
  isLoading: true,
  error: null,
  loginMutation: defaultMutationState,
  logoutMutation: defaultMutationState,
  registerMutation: defaultMutationState,
};

// Create the context with default values
export const AuthContext = createContext<AuthContextType>(defaultContext);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [error, setError] = useState<Error | null>(null);

  // Fetch the user data from our backend
  const {
    data: user,
    isLoading,
  } = useQuery<SelectUser | undefined, Error>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  // Login handler function with direct backend authentication
  const handleLogin = useCallback(async (credentials: LoginData) => {
    try {
      // Authenticate with our backend
      const res = await apiRequest("POST", "/api/login", credentials);
      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.message || "Login failed");
      }
      
      return data;
    } catch (error: any) {
      console.error("Login error:", error);
      throw new Error(error.message || "Invalid email or password");
    }
  }, []);

  // Register handler function with direct backend registration
  const handleRegister = useCallback(async (userData: InsertUser) => {
    try {
      // Register with our backend
      const res = await apiRequest("POST", "/api/register", userData);
      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.message || "Registration failed");
      }
      
      return data;
    } catch (error: any) {
      console.error("Registration error:", error);
      throw new Error(error.message || "Registration failed");
    }
  }, []);
  
  // Logout handler function with direct backend logout
  const handleLogout = useCallback(async () => {
    try {
      // Logout from backend
      const res = await apiRequest("POST", "/api/logout");
      
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || "Logout failed");
      }
    } catch (error: any) {
      console.error("Logout error:", error);
      throw new Error(error.message || "Failed to log out");
    }
  }, []);

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: handleLogin,
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      queryClient.invalidateQueries({queryKey: ["/api/user"]});
      
      toast({
        title: "Login successful",
        description: `Welcome back, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: handleRegister,
    onSuccess: (response: any) => {
      // Check if the user is pending approval
      if (response.pendingApproval) {
        toast({
          title: "Registration successful",
          description: "Your account has been created and is pending approval.",
        });
      } else {
        queryClient.setQueryData(["/api/user"], response);
        toast({
          title: "Registration successful",
          description: `Welcome, ${response.username}!`,
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: handleLogout,
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Create context value
  const contextValue: AuthContextType = {
    user: user ?? null,
    isLoading,
    error,
    loginMutation,
    logoutMutation,
    registerMutation,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}