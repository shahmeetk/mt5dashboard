import { createContext, ReactNode, useContext, useEffect, useState, useCallback } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User as SelectUser, InsertUser } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { auth } from "../lib/firebase";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser
} from "firebase/auth";

// Simple auth context type
type AuthContextType = {
  user: SelectUser | null;
  isLoading: boolean;
  error: Error | null;
  firebaseUser: FirebaseUser | null;
  loginMutation: UseMutationResult<SelectUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SelectUser, Error, InsertUser>;
};

// Login data type for mutations
type LoginData = {
  email: string;
  password: string;
};

// Create the context with default values to avoid circular dependencies
const defaultMutationState = {
  mutate: () => {},
  isPending: false,
  isSuccess: false,
  isError: false,
  error: null,
  reset: () => {},
} as any;

const defaultContext: AuthContextType = {
  user: null,
  isLoading: true,
  error: null,
  firebaseUser: null,
  loginMutation: defaultMutationState,
  logoutMutation: defaultMutationState,
  registerMutation: defaultMutationState,
};

// Create the context with default values
export const AuthContext = createContext<AuthContextType>(defaultContext);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [initializing, setInitializing] = useState(true);
  
  // Firebase Auth state listener
  useEffect(() => {
    console.log('Auth provider initialized');
    
    if (!auth) {
      console.log('Firebase auth not initialized, using development mode');
      setInitializing(false);
      return;
    }
    
    try {
      const unsubscribe = onAuthStateChanged(auth, (user) => {
        setFirebaseUser(user);
        if (initializing) setInitializing(false);
      });
      
      return unsubscribe;
    } catch (error) {
      console.error('Error setting up auth state listener:', error);
      setInitializing(false);
      return undefined;
    }
  }, [initializing]);

  // Fetch the user data from our backend
  const {
    data: user,
    error,
    isLoading: userDataLoading,
  } = useQuery<SelectUser | undefined, Error>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!firebaseUser, // Only run this query when we have a Firebase user
  });

  // Combined loading state
  const isLoading = initializing || (!!firebaseUser && userDataLoading);

  // Login handler function with Firebase
  const handleLogin = useCallback(async (credentials: LoginData) => {
    try {
      // Check if Firebase is initialized
      if (!auth) {
        throw new Error("Firebase authentication is not available. Please check your API key.");
      }
      
      // First authenticate with Firebase
      await signInWithEmailAndPassword(auth, credentials.email, credentials.password);
      
      // Then authenticate with our backend
      const res = await apiRequest("POST", "/api/login", credentials);
      return await res.json();
    } catch (firebaseError: any) {
      // Map Firebase errors to more user-friendly messages
      let errorMessage = "Authentication failed";
      switch(firebaseError.code) {
        case 'auth/user-not-found':
        case 'auth/wrong-password':
          errorMessage = "Invalid email or password";
          break;
        case 'auth/too-many-requests':
          errorMessage = "Too many failed login attempts, please try again later";
          break;
        case 'auth/invalid-api-key':
          errorMessage = "Firebase API configuration error. Please contact support.";
          break;
        default:
          errorMessage = firebaseError.message || "Login failed. Please try again.";
      }
      console.error("Login error:", firebaseError);
      throw new Error(errorMessage);
    }
  }, []);

  // Register handler function with Firebase
  const handleRegister = useCallback(async (userData: InsertUser) => {
    try {
      // Check if Firebase is initialized
      if (!auth) {
        throw new Error("Firebase authentication is not available. Please check your API key.");
      }
      
      // Create user in Firebase first
      if (!userData.email || !userData.password) {
        throw new Error("Email and password are required");
      }
      
      // Create Firebase user first
      await createUserWithEmailAndPassword(auth, userData.email, userData.password);
      
      // Then register with our backend
      const res = await apiRequest("POST", "/api/register", userData);
      return await res.json();
    } catch (firebaseError: any) {
      // Map Firebase errors to more user-friendly messages
      let errorMessage = "Registration failed";
      switch(firebaseError.code) {
        case 'auth/email-already-in-use':
          errorMessage = "Email is already in use";
          break;
        case 'auth/weak-password':
          errorMessage = "Password is too weak";
          break;
        case 'auth/invalid-api-key':
          errorMessage = "Firebase API configuration error. Please contact support.";
          break;  
        default:
          errorMessage = firebaseError.message || "Registration failed. Please try again.";
      }
      console.error("Registration error:", firebaseError);
      throw new Error(errorMessage);
    }
  }, []);
  
  // Logout handler function with Firebase
  const handleLogout = useCallback(async () => {
    try {
      // Check if Firebase is initialized
      if (auth) {
        // Sign out from Firebase
        await signOut(auth);
      }
      
      // Then logout from our backend
      await apiRequest("POST", "/api/logout");
    } catch (error: any) {
      console.error("Logout error:", error);
      throw new Error(error.message || "Failed to log out. Please try again.");
    }
  }, []);

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: handleLogin,
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Login successful",
        description: `Welcome back, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: handleRegister,
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: `Welcome, ${user.username}! Your account is pending approval.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: handleLogout,
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Create context value
  const contextValue: AuthContextType = {
    user: user ?? null,
    isLoading,
    error,
    firebaseUser,
    loginMutation,
    logoutMutation,
    registerMutation,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
