import { Mt5AccountData, Mt5Position } from '@shared/schema';

type WebSocketMessageType = 'mt5-account-update' | 'mt5-positions-update' | 'mt5-connection-warning';

type WebSocketMessage = {
  type: WebSocketMessageType;
  data: any;
};

type WebSocketEventHandlers = {
  onAccountUpdate?: (data: Mt5AccountData) => void;
  onPositionsUpdate?: (data: Mt5Position[]) => void;
  onConnectionWarning?: (data: { message: string; time: string }) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: Event) => void;
};

class Mt5WebSocketClient {
  private socket: WebSocket | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectInterval = 3000; // 3 seconds
  private eventHandlers: WebSocketEventHandlers = {};
  private isConnected = false;

  constructor() {
    this.connect();
  }

  public connect(): void {
    if (this.socket?.readyState === WebSocket.OPEN) {
      return; // Already connected
    }

    try {
      // Create WebSocket connection
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      this.socket = new WebSocket(wsUrl);

      this.socket.onopen = this.handleOpen.bind(this);
      this.socket.onmessage = this.handleMessage.bind(this);
      this.socket.onclose = this.handleClose.bind(this);
      this.socket.onerror = this.handleError.bind(this);
    } catch (error) {
      console.error('WebSocket connection error:', error);
      this.scheduleReconnect();
    }
  }

  public disconnect(): void {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  public on<K extends keyof WebSocketEventHandlers>(
    event: K,
    handler: WebSocketEventHandlers[K]
  ): void {
    this.eventHandlers[event] = handler;
  }

  private handleOpen(event: Event): void {
    console.log('WebSocket connection established');
    this.isConnected = true;
    this.reconnectAttempts = 0;

    // Call the onConnect handler if it exists
    if (this.eventHandlers.onConnect) {
      this.eventHandlers.onConnect();
    }
  }

  private handleMessage(event: MessageEvent): void {
    try {
      const message = JSON.parse(event.data) as WebSocketMessage;

      switch (message.type) {
        case 'mt5-account-update':
          if (this.eventHandlers.onAccountUpdate) {
            this.eventHandlers.onAccountUpdate(message.data);
          }
          break;
        case 'mt5-positions-update':
          if (this.eventHandlers.onPositionsUpdate) {
            this.eventHandlers.onPositionsUpdate(message.data);
          }
          break;
        case 'mt5-connection-warning':
          if (this.eventHandlers.onConnectionWarning) {
            this.eventHandlers.onConnectionWarning(message.data);
          }
          break;
        default:
          console.warn('Unknown message type:', message.type);
      }
    } catch (error) {
      console.error('Error parsing WebSocket message:', error, event.data);
    }
  }

  private handleClose(event: CloseEvent): void {
    console.log(`WebSocket connection closed: ${event.code} ${event.reason}`);
    this.isConnected = false;

    // Call the onDisconnect handler if it exists
    if (this.eventHandlers.onDisconnect) {
      this.eventHandlers.onDisconnect();
    }

    // Attempt to reconnect if the connection was unexpectedly closed
    if (event.code !== 1000) {
      this.scheduleReconnect();
    }
  }

  private handleError(event: Event): void {
    console.error('WebSocket error:', event);

    // Call the onError handler if it exists
    if (this.eventHandlers.onError) {
      this.eventHandlers.onError(event);
    }

    this.scheduleReconnect();
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }

    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = this.reconnectInterval * this.reconnectAttempts;
      console.log(`Scheduling reconnect attempt ${this.reconnectAttempts} in ${delay}ms`);

      this.reconnectTimer = setTimeout(() => {
        console.log(`Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        this.connect();
      }, delay);
    } else {
      console.error(`Failed to reconnect after ${this.maxReconnectAttempts} attempts`);
    }
  }

  public isConnectedToServer(): boolean {
    return this.isConnected;
  }

  public getConnectionStatus(): 'connected' | 'connecting' | 'disconnected' {
    if (!this.socket) return 'disconnected';
    
    switch (this.socket.readyState) {
      case WebSocket.CONNECTING:
        return 'connecting';
      case WebSocket.OPEN:
        return 'connected';
      default:
        return 'disconnected';
    }
  }
}

// Create a singleton instance
const mt5WebSocketClient = new Mt5WebSocketClient();

export default mt5WebSocketClient;