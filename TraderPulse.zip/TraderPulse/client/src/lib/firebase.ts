import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getDatabase } from "firebase/database";
import { getAuth } from "firebase/auth";

// Development mode fallback
class MockFirestore {
  collection() {
    return this;
  }
  where() {
    return this;
  }
  doc() {
    return this;
  }
  getDocs() {
    return Promise.resolve({ docs: [] });
  }
  getDoc() {
    return Promise.resolve({ exists: () => false, data: () => ({}) });
  }
  setDoc() {
    return Promise.resolve();
  }
  updateDoc() {
    return Promise.resolve();
  }
  deleteDoc() {
    return Promise.resolve();
  }
}

class MockDatabase {
  ref() {
    return this;
  }
  on() {
    return null;
  }
  off() {
    return null;
  }
  onValue(ref: any, callback: (snapshot: any) => void) {
    // Simulate an empty snapshot
    callback({ 
      val: () => null
    });
    return null;
  }
}

// Using any type to avoid TypeScript errors in other files
let app: any;
let auth: any;
let firestore: any;
let database: any;

// Development mode flag - set to true to use mock implementations
const USE_MOCK_FIREBASE = true;

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAa9Cp-x7jITTHPXFRn8C_lXaJKaJwRxKw", // Will be replaced by our env var when we can set it up properly
  authDomain: "mt5monitor-01.firebaseapp.com",
  databaseURL: "https://mt5monitor-01-default-rtdb.firebaseio.com",
  projectId: "mt5monitor-01",
  storageBucket: "mt5monitor-01.appspot.com",
  messagingSenderId: "252326289960",
  appId: "1:252326289960:web:f1d7fb9e1ea0eba56f9aad"
};

// Create a mock auth object that mimics Firebase Auth
class MockAuth {
  private currentUser: any = null;
  private listeners: ((user: any) => void)[] = [];

  async signInWithEmailAndPassword(email: string, password: string) {
    // For demo purposes, validate hardcoded credentials
    if (email === "shahmeetk@gmail.com" && password === "Smk@10290") {
      this.currentUser = {
        uid: "admin-uid-123",
        email: email,
        displayName: "Admin User"
      };
      this.notifyListeners();
      return { user: this.currentUser };
    }
    throw new Error("auth/wrong-password");
  }

  async createUserWithEmailAndPassword(email: string, password: string) {
    this.currentUser = {
      uid: "user-" + Date.now(),
      email: email,
      displayName: email.split('@')[0]
    };
    this.notifyListeners();
    return { user: this.currentUser };
  }

  async signOut() {
    this.currentUser = null;
    this.notifyListeners();
  }

  onAuthStateChanged(callback: (user: any) => void) {
    this.listeners.push(callback);
    callback(this.currentUser);
    return () => {
      this.listeners = this.listeners.filter(listener => listener !== callback);
    };
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.currentUser));
  }
}

if (USE_MOCK_FIREBASE) {
  console.log("Using mock Firebase implementation");
  app = null;
  auth = new MockAuth();
  firestore = new MockFirestore();
  database = new MockDatabase();
} else {
  try {
    // Initialize Firebase
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    firestore = getFirestore(app);
    database = getDatabase(app);
    console.log("Firebase initialized successfully");
  } catch (e) {
    console.error("Error initializing Firebase:", e);
    
    // Fallback to mock implementations
    app = null;
    auth = new MockAuth();
    firestore = new MockFirestore();
    database = new MockDatabase();
    console.log("Using development mode with mock implementations");
  }
}

export { app, auth, firestore, database };