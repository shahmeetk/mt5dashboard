import { collection, doc, getDoc, setDoc, updateDoc, deleteDoc, query, where, getDocs } from "firebase/firestore";
import { ref, onValue, off } from "firebase/database";
import { Mt5AccountData, Mt5Position } from "@shared/schema";
import mt5WebSocketClient from "./websocket-client";
import axios from "axios";

// Import with type annotations to fix TS errors
import { firestore, database } from "./firebase";

// Mock data for development mode
const MOCK_ACCOUNTS: Mt5AccountData[] = [
  {
    accountNumber: "12345678",
    accountName: "Main Trading",
    brokerName: "AvaTrade",
    balance: 10000.50,
    equity: 10300.75,
    margin: 500.25,
    freeMargin: 9800.50,
    marginLevel: 2060.15,
    profit: 300.25,
    positions: 2,
    lastUpdated: new Date().toISOString(),
    status: "healthy"
  },
  {
    accountNumber: "87654321",
    accountName: "Test Account",
    brokerName: "Mex Atlantic",
    balance: 5000.00,
    equity: 4800.40,
    margin: 300.75,
    freeMargin: 4500.00,
    marginLevel: 1600.30,
    profit: -199.60,
    positions: 1,
    lastUpdated: new Date().toISOString(),
    status: "warning"
  },
  {
    accountNumber: "98765432",
    accountName: "Risk Portfolio",
    brokerName: "JKV Global",
    balance: 20000.00,
    equity: 22540.80,
    margin: 3000.50,
    freeMargin: 19540.30,
    marginLevel: 751.50,
    profit: 2540.80,
    positions: 5,
    lastUpdated: new Date().toISOString(),
    status: "healthy"
  },
  {
    accountNumber: "45678912",
    accountName: "Conservative",
    brokerName: "AvaTrade",
    balance: 15000.00,
    equity: 15200.50,
    margin: 1200.75,
    freeMargin: 14000.00,
    marginLevel: 1266.30,
    profit: 200.50,
    positions: 3,
    lastUpdated: new Date().toISOString(),
    status: "healthy"
  }
];

const MOCK_POSITIONS: Mt5Position[] = [
  {
    accountNumber: "12345678",
    accountName: "Main Trading",
    symbol: "EURUSD",
    type: "BUY",
    volume: 0.10,
    openPrice: 1.08750,
    currentPrice: 1.09240,
    profit: 49.00,
    profitPercent: 0.45,
    ticket: 1234567
  },
  {
    accountNumber: "12345678",
    accountName: "Main Trading",
    symbol: "GBPUSD",
    type: "BUY",
    volume: 0.25,
    openPrice: 1.27450,
    currentPrice: 1.28890,
    profit: 251.25,
    profitPercent: 1.13,
    ticket: 1234568
  },
  {
    accountNumber: "87654321",
    accountName: "Test Account",
    symbol: "USDJPY",
    type: "SELL",
    volume: 0.50,
    openPrice: 149.850,
    currentPrice: 150.250,
    profit: -199.60,
    profitPercent: -0.27,
    ticket: 8765432
  },
  {
    accountNumber: "98765432",
    accountName: "Risk Portfolio",
    symbol: "XAUUSD",
    type: "BUY",
    volume: 0.20,
    openPrice: 2324.50,
    currentPrice: 2392.75,
    profit: 1366.00,
    profitPercent: 2.94,
    ticket: 9876543
  },
  {
    accountNumber: "98765432",
    accountName: "Risk Portfolio",
    symbol: "US30",
    type: "BUY",
    volume: 0.05,
    openPrice: 39150.0,
    currentPrice: 39840.5,
    profit: 345.25,
    profitPercent: 1.76,
    ticket: 9876544
  },
  {
    accountNumber: "45678912",
    accountName: "Conservative",
    symbol: "EURGBP",
    type: "SELL",
    volume: 0.15,
    openPrice: 0.8540,
    currentPrice: 0.8520,
    profit: 30.00,
    profitPercent: 0.23,
    ticket: 4567891
  }
];

// Flag to determine whether to use WebSocket or Firebase
const USE_WEBSOCKET = true;

let lastAccountData: Mt5AccountData | null = null;
let lastPositions: Mt5Position[] = [];

// Initialize WebSocket for real-time updates
mt5WebSocketClient.on('onAccountUpdate', (data: Mt5AccountData) => {
  lastAccountData = data;
});

mt5WebSocketClient.on('onPositionsUpdate', (data: Mt5Position[]) => {
  lastPositions = data;
});

mt5WebSocketClient.on('onConnectionWarning', (data: { message: string; time: string }) => {
  console.warn('MT5 connection warning:', data.message, 'at', data.time);
});

export async function fetchMt5Accounts(userId: string, broker?: string): Promise<Mt5AccountData[]> {
  // For development mode, return mock data with optional broker filtering
  return new Promise((resolve) => {
    setTimeout(() => {
      if (broker) {
        // Filter accounts by broker name if specified
        const filteredAccounts = MOCK_ACCOUNTS.filter(
          account => account.brokerName.toLowerCase() === broker.toLowerCase()
        );
        resolve(filteredAccounts);
      } else {
        resolve(MOCK_ACCOUNTS);
      }
    }, 500); // Simulate network delay
  });
  
  // In production, you would use this code instead:
  /* 
  try {
    if (USE_WEBSOCKET) {
      // Try to fetch from our server API first
      try {
        // Build URL with optional broker query parameter
        const url = broker 
          ? `/api/mt5-accounts?broker=${encodeURIComponent(broker)}` 
          : '/api/mt5-accounts';
          
        const response = await axios.get(url);
        return response.data;
      } catch (apiError) {
        console.error("Error fetching MT5 accounts from API:", apiError);
        
        // Fall back to Firebase if API fails
        if (lastAccountData) {
          return [lastAccountData];
        }
      }
    }
    
    // Fallback to Firebase
    let q = query(collection(firestore, "mt5Accounts"), where("userId", "==", userId));
    
    // Add broker filter if specified
    if (broker) {
      q = query(q, where("brokerName", "==", broker));
    }
    
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        ...data,
        id: doc.id,
      } as Mt5AccountData;
    });
  } catch (error) {
    console.error("Error fetching MT5 accounts:", error);
    
    // Last resort fallback to cached data
    if (lastAccountData) {
      return [lastAccountData];
    }
    
    throw error;
  }
  */
}

export async function fetchMt5Positions(userId: string, broker?: string): Promise<Mt5Position[]> {
  // For development mode, return mock data with optional broker filtering
  return new Promise((resolve) => {
    setTimeout(() => {
      if (broker) {
        // Get all accounts for this broker
        const brokerAccounts = MOCK_ACCOUNTS.filter(
          account => account.brokerName.toLowerCase() === broker.toLowerCase()
        );
        
        // Filter positions by account numbers from this broker
        const accountNumbers = brokerAccounts.map(account => account.accountNumber);
        const filteredPositions = MOCK_POSITIONS.filter(
          position => accountNumbers.includes(position.accountNumber)
        );
        
        resolve(filteredPositions);
      } else {
        resolve(MOCK_POSITIONS);
      }
    }, 700); // Simulate network delay
  });
  
  // In production, you would use this code instead:
  /*
  try {
    if (USE_WEBSOCKET) {
      // Try to fetch from our server API first
      try {
        // Build URL with optional broker query parameter
        const url = broker 
          ? `/api/mt5-positions?broker=${encodeURIComponent(broker)}` 
          : '/api/mt5-positions';
          
        const response = await axios.get(url);
        return response.data;
      } catch (apiError) {
        console.error("Error fetching MT5 positions from API:", apiError);
        
        // Fall back to last WebSocket update if available
        if (lastPositions.length > 0) {
          return lastPositions;
        }
      }
    }
    
    // Fallback to Firebase
    if (broker) {
      // First get the accounts for this broker
      const accountsQuery = query(
        collection(firestore, "mt5Accounts"), 
        where("userId", "==", userId),
        where("brokerName", "==", broker)
      );
      const accountsSnapshot = await getDocs(accountsQuery);
      const accountNumbers = accountsSnapshot.docs.map(doc => doc.data().accountNumber);
      
      // Now get positions for these accounts
      const positions: Mt5Position[] = [];
      
      if (accountNumbers.length > 0) {
        // We need to do multiple queries since Firebase doesn't support "IN" with arrays
        for (const accountNumber of accountNumbers) {
          const positionsQuery = query(
            collection(firestore, "mt5Positions"), 
            where("accountNumber", "==", accountNumber)
          );
          const positionsSnapshot = await getDocs(positionsQuery);
          
          positions.push(
            ...positionsSnapshot.docs.map(doc => {
              const data = doc.data();
              return {
                ...data,
                id: doc.id,
              } as Mt5Position;
            })
          );
        }
      }
      
      return positions;
    } else {
      // Get all positions for the user
      const q = query(collection(firestore, "mt5Positions"), where("userId", "==", userId));
      const querySnapshot = await getDocs(q);
      
      return querySnapshot.docs.map(doc => {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
        } as Mt5Position;
      });
    }
  } catch (error) {
    console.error("Error fetching MT5 positions:", error);
    
    // Last resort fallback to cached data
    if (lastPositions.length > 0) {
      return lastPositions;
    }
    
    throw error;
  }
  */
}

export function subscribeToMt5AccountUpdates(userId: string, callback: (accounts: Mt5AccountData[]) => void) {
  // For development mode, simulate real-time updates with random fluctuations
  const interval = setInterval(() => {
    const updatedAccounts = MOCK_ACCOUNTS.map(account => ({
      ...account,
      equity: account.equity * (1 + (Math.random() * 0.02 - 0.01)), // Random fluctuation ±1%
      profit: account.profit * (1 + (Math.random() * 0.04 - 0.02)), // Random fluctuation ±2%
      lastUpdated: new Date().toISOString(),
    }));
    
    callback(updatedAccounts);
  }, 5000); // Update every 5 seconds
  
  // Return unsubscribe function
  return () => clearInterval(interval);
  
  /* In production, use this code instead:
  if (USE_WEBSOCKET) {
    // Set up WebSocket subscription
    mt5WebSocketClient.on('onAccountUpdate', (data: Mt5AccountData) => {
      lastAccountData = data;
      callback([data]);
    });
    
    // Return unsubscribe function
    return () => {
      // No need to unsubscribe from WebSocket here, as it's a singleton
      // We might just want to remove this specific callback in a more complex application
    };
  }
  
  // Fallback to Firebase
  const accountsRef = ref(database, `mt5Updates/${userId}/accounts`);
  
  onValue(accountsRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const accounts = Object.values(data) as Mt5AccountData[];
      callback(accounts);
    } else {
      callback([]);
    }
  });
  
  return () => off(accountsRef);
  */
}

export function subscribeToMt5PositionUpdates(userId: string, callback: (positions: Mt5Position[]) => void) {
  // For development mode, simulate real-time updates with random fluctuations
  const interval = setInterval(() => {
    const updatedPositions = MOCK_POSITIONS.map(position => ({
      ...position,
      currentPrice: position.currentPrice * (1 + (Math.random() * 0.01 - 0.005)), // Random fluctuation ±0.5%
      profit: position.profit * (1 + (Math.random() * 0.05 - 0.025)), // Random fluctuation ±2.5%
    }));
    
    callback(updatedPositions);
  }, 8000); // Update every 8 seconds
  
  // Return unsubscribe function
  return () => clearInterval(interval);
  
  /* In production, use this code instead:
  if (USE_WEBSOCKET) {
    // Set up WebSocket subscription
    mt5WebSocketClient.on('onPositionsUpdate', (data: Mt5Position[]) => {
      lastPositions = data;
      callback(data);
    });
    
    // Return unsubscribe function
    return () => {
      // No need to unsubscribe from WebSocket here, as it's a singleton
      // We might just want to remove this specific callback in a more complex application
    };
  }
  
  // Fallback to Firebase
  const positionsRef = ref(database, `mt5Updates/${userId}/positions`);
  
  onValue(positionsRef, (snapshot) => {
    const data = snapshot.val();
    if (data) {
      const positions = Object.values(data) as Mt5Position[];
      callback(positions);
    } else {
      callback([]);
    }
  });
  
  return () => off(positionsRef);
  */
}

export async function saveMt5Account(userId: string, accountData: Partial<Mt5AccountData> & { accountNumber: string }) {
  try {
    // First try the API endpoint
    if (USE_WEBSOCKET) {
      try {
        await axios.post('/api/mt5-accounts', {
          ...accountData,
          userId
        });
        return;
      } catch (apiError) {
        console.error("Error saving MT5 account to API:", apiError);
        // Fall back to Firebase
      }
    }
    
    // Fallback to Firebase
    const accountRef = doc(firestore, "mt5Accounts", accountData.accountNumber);
    const accountDoc = await getDoc(accountRef);
    
    if (accountDoc.exists()) {
      await updateDoc(accountRef, {
        ...accountData,
        userId,
        lastUpdated: new Date().toISOString()
      });
    } else {
      await setDoc(accountRef, {
        ...accountData,
        userId,
        lastUpdated: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error("Error saving MT5 account:", error);
    throw error;
  }
}

export async function deleteMt5Account(accountNumber: string) {
  try {
    // First try the API endpoint
    if (USE_WEBSOCKET) {
      try {
        await axios.delete(`/api/mt5-accounts/${accountNumber}`);
        return;
      } catch (apiError) {
        console.error("Error deleting MT5 account via API:", apiError);
        // Fall back to Firebase
      }
    }
    
    // Fallback to Firebase
    await deleteDoc(doc(firestore, "mt5Accounts", accountNumber));
  } catch (error) {
    console.error("Error deleting MT5 account:", error);
    throw error;
  }
}

// Additional utility functions

export function getMt5ConnectionStatus(): 'connected' | 'connecting' | 'disconnected' {
  return mt5WebSocketClient.getConnectionStatus();
}

export async function testMt5Connection(): Promise<{ connected: boolean; message: string }> {
  // In development mode, always return successful connection
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        connected: true,
        message: 'Connected to MT5 server successfully'
      });
    }, 300);
  });
  
  /* In production, use this code:
  try {
    const response = await axios.get('/api/mt5-connection-test');
    return response.data;
  } catch (error) {
    return {
      connected: false,
      message: 'Could not connect to MT5 server. Please check your credentials.'
    };
  }
  */
}
