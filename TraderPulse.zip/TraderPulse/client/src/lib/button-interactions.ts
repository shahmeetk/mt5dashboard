/**
 * Creates a ripple effect when a button is clicked
 * @param event - The click event
 */
export function createRipple(event: React.MouseEvent<HTMLButtonElement>) {
  const button = event.currentTarget;
  
  // Get button position
  const rect = button.getBoundingClientRect();
  
  // Calculate ripple position relative to the button
  const x = event.clientX - rect.left;
  const y = event.clientY - rect.top;
  
  // Create ripple element
  const ripple = document.createElement('span');
  ripple.classList.add('ripple');
  ripple.style.left = `${x}px`;
  ripple.style.top = `${y}px`;
  
  // Set ripple size based on button dimensions
  const size = Math.max(rect.width, rect.height);
  ripple.style.width = `${size}px`;
  ripple.style.height = `${size}px`;
  
  // Add ripple to button
  button.appendChild(ripple);
  
  // Remove ripple after animation completes
  setTimeout(() => {
    ripple.remove();
  }, 600);
}

/**
 * Creates a button hover effect that follows the cursor
 * @param event - The mousemove event
 */
export function followCursor(event: React.MouseEvent<HTMLButtonElement>) {
  const button = event.currentTarget;
  const rect = button.getBoundingClientRect();
  
  // Calculate position relative to the button center
  const x = event.clientX - rect.left - rect.width / 2;
  const y = event.clientY - rect.top - rect.height / 2;
  
  // Limit the tilt amount
  const tiltX = y / 10;
  const tiltY = -x / 10;
  
  // Apply transform
  button.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(1.02, 1.02, 1.02)`;
}

/**
 * Resets button transform when mouse leaves
 * @param event - The mouseleave event
 */
export function resetButtonTransform(event: React.MouseEvent<HTMLButtonElement>) {
  const button = event.currentTarget;
  button.style.transform = '';
}