import { Activity, Building, Clock, ExternalLink, AlertTriangle, Shield, LineChart } from "lucide-react";
import { Link } from "wouter";
import { Mt5AccountData } from "@shared/schema";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface AccountCardProps {
  account: Mt5AccountData;
}

export default function AccountCard({ account }: AccountCardProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  // Enhanced health status indicator functions
  const getHealthStatusDetails = (status: string, marginLevel: number) => {
    switch (status) {
      case 'healthy':
        return {
          icon: <Shield className="h-4 w-4 mr-1.5" />,
          color: 'bg-green-100 text-green-600 border-green-200',
          hoverColor: 'hover:bg-green-50',
          pulseColor: 'bg-green-400',
          label: 'Healthy',
          description: 'Account is in good standing with adequate margin and balanced risk.',
          marginText: marginLevel > 500 
            ? 'Excellent margin level'
            : 'Good margin level'
        };
      case 'warning':
        return {
          icon: <AlertTriangle className="h-4 w-4 mr-1.5" />,
          color: 'bg-yellow-100 text-yellow-600 border-yellow-200',
          hoverColor: 'hover:bg-yellow-50',
          pulseColor: 'bg-yellow-400',
          label: 'Warning',
          description: 'Account requires attention. Margin level or other metrics are approaching risk thresholds.',
          marginText: 'Margin level needs attention'
        };
      default:
        return {
          icon: <Activity className="h-4 w-4 mr-1.5" />,
          color: 'bg-red-100 text-red-600 border-red-200',
          hoverColor: 'hover:bg-red-50',
          pulseColor: 'bg-red-400',
          label: 'Danger',
          description: 'Account is at high risk. Immediate action may be required to prevent a margin call.',
          marginText: 'Critical margin level'
        };
    }
  };

  const getMarginLevelColor = (level: number) => {
    if (level > 500) return 'bg-green-600';
    if (level > 300) return 'bg-green-500';
    if (level > 200) return 'bg-yellow-500';
    if (level > 100) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getMarginLevelWidth = (level: number) => {
    // Cap at 100%
    const percentage = Math.min(level / 10, 100);
    return `${percentage}%`;
  };

  const calculateTimeAgo = (lastUpdated: string) => {
    const now = new Date();
    const updated = new Date(lastUpdated);
    const diffInSeconds = Math.floor((now.getTime() - updated.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return `${diffInSeconds}s ago`;
    } else if (diffInSeconds < 3600) {
      return `${Math.floor(diffInSeconds / 60)}m ago`;
    } else if (diffInSeconds < 86400) {
      return `${Math.floor(diffInSeconds / 3600)}h ago`;
    } else {
      return `${Math.floor(diffInSeconds / 86400)}d ago`;
    }
  };

  // Get the details for current health status
  const healthStatus = getHealthStatusDetails(account.status, account.marginLevel);
  
  // Calculate equity to balance ratio
  const equityRatio = (account.equity / account.balance) * 100;
  const equityStatus = equityRatio >= 100 
    ? 'text-green-600' 
    : equityRatio >= 90 
      ? 'text-yellow-600' 
      : 'text-red-600';
  
  return (
    <div className={`bg-white rounded-lg shadow-sm border transition-all duration-200 overflow-hidden ${account.status === 'danger' ? 'border-red-200' : account.status === 'warning' ? 'border-yellow-200' : 'border-neutral-200'}`}>
      <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
        <div className="flex items-center">
          <div className={`w-10 h-10 ${account.status === 'healthy' ? 'bg-primary/10' : account.status === 'warning' ? 'bg-yellow-100' : 'bg-red-100'} rounded-md flex items-center justify-center mr-3 transition-colors duration-300`}>
            <Building className={account.status === 'healthy' ? 'text-primary' : account.status === 'warning' ? 'text-yellow-600' : 'text-red-600'} />
          </div>
          <div>
            <h3 className="font-medium text-neutral-800">{account.accountName}</h3>
            <p className="text-xs text-neutral-500">Account #{account.accountNumber}</p>
          </div>
        </div>
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className={`px-3 py-1.5 rounded-md flex items-center cursor-help ${healthStatus.color} ${healthStatus.hoverColor} transition-colors duration-200 border`}>
                <div className="relative mr-0.5">
                  <div className="absolute -top-1 -left-1 w-2 h-2 rounded-full animate-ping opacity-75 transition-opacity duration-1000 ease-in-out" style={{ backgroundColor: account.status === 'danger' ? '#f87171' : account.status === 'warning' ? '#facc15' : '#4ade80' }}></div>
                  <div className={`w-2 h-2 rounded-full ${healthStatus.pulseColor}`}></div>
                </div>
                {healthStatus.icon}
                <span className="text-xs font-medium capitalize whitespace-nowrap">{healthStatus.label}</span>
              </div>
            </TooltipTrigger>
            <TooltipContent side="right" className="max-w-xs">
              <div className="space-y-2">
                <p className="font-medium">{healthStatus.label} Status</p>
                <p className="text-sm text-neutral-600">{healthStatus.description}</p>
                <ul className="text-xs text-neutral-500 pl-5 list-disc space-y-1">
                  <li>Margin Level: {account.marginLevel.toFixed(2)}% ({healthStatus.marginText})</li>
                  <li>Equity: {formatCurrency(account.equity)} ({equityRatio.toFixed(2)}% of balance)</li>
                  <li>Free Margin: {formatCurrency(account.freeMargin)}</li>
                </ul>
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="flex items-center mb-1">
              <p className="text-xs text-neutral-500">Balance</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="ml-1 cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Total funds in your account without including open positions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <p className="text-lg font-mono font-medium">{formatCurrency(account.balance)}</p>
          </div>
          <div>
            <div className="flex items-center mb-1">
              <p className="text-xs text-neutral-500">Equity</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="ml-1 cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Balance + floating P/L from open positions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <p className={`text-lg font-mono font-medium ${equityStatus}`}>{formatCurrency(account.equity)}</p>
          </div>
          <div>
            <div className="flex items-center mb-1">
              <p className="text-xs text-neutral-500">Margin</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="ml-1 cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Collateral required to maintain open positions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <p className="text-lg font-mono font-medium">{formatCurrency(account.margin)}</p>
          </div>
          <div>
            <div className="flex items-center mb-1">
              <p className="text-xs text-neutral-500">Free Margin</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="ml-1 cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Funds available for new positions or withdrawals</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <p className="text-lg font-mono font-medium">{formatCurrency(account.freeMargin)}</p>
          </div>
        </div>
        
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center">
            <p className="text-xs text-neutral-500 mr-1">Open P/L</p>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="cursor-help">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                      <circle cx="12" cy="12" r="10" />
                      <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                      <line x1="12" y1="17" x2="12.01" y2="17" />
                    </svg>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs">Current profit/loss from open positions</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="flex items-center">
            <LineChart className={`h-3 w-3 mr-1 ${account.profit >= 0 ? 'text-green-500' : 'text-red-500'}`} />
            <p className={`text-sm font-mono font-medium ${account.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {account.profit >= 0 ? '+' : ''}{formatCurrency(account.profit)}
            </p>
          </div>
        </div>
        
        <div className="relative pt-1">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center">
              <p className="text-xs text-neutral-500 mr-1">Margin Level</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <div className="space-y-1">
                      <p className="text-xs">Equity/Margin ratio as a percentage</p>
                      <ul className="text-xs text-neutral-500 pl-5 list-disc space-y-0.5">
                        <li>500%+ Excellent</li>
                        <li>300-500% Good</li>
                        <li>200-300% Caution</li>
                        <li>&lt;200% Warning</li>
                        <li>&lt;100% Danger (margin call)</li>
                      </ul>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <p className={`text-xs font-medium ${
              account.marginLevel > 500 ? 'text-green-600' : 
              account.marginLevel > 300 ? 'text-green-500' : 
              account.marginLevel > 200 ? 'text-yellow-600' :
              account.marginLevel > 100 ? 'text-orange-600' : 'text-red-600'
            }`}>{account.marginLevel.toFixed(2)}%</p>
          </div>
          <div className="overflow-hidden h-2 text-xs flex rounded bg-neutral-200">
            <div 
              style={{ width: getMarginLevelWidth(account.marginLevel) }} 
              className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center ${getMarginLevelColor(account.marginLevel)} transition-all duration-500`}
            ></div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center space-x-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-primary/10 text-primary">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-3 w-3 mr-1">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="17 8 12 3 7 8"></polyline>
                <line x1="12" y1="3" x2="12" y2="15"></line>
              </svg>
              {account.positions} positions
            </span>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-neutral-100 text-neutral-800">
              <Clock className="h-3 w-3 mr-1" />
              {calculateTimeAgo(account.lastUpdated)}
            </span>
          </div>
          <Link href={`/account/${account.accountNumber}`} className="text-primary text-xs font-medium flex items-center hover:underline transition-all">
            View Details
            <ExternalLink className="h-3 w-3 ml-1" />
          </Link>
        </div>
      </div>
    </div>
  );
}
