import { AlertTriangle, AlertCircle } from "lucide-react";

// Mock alerts for development mode
const MOCK_ALERTS = [
  {
    id: 1,
    accountNumber: "12345678",
    alertType: "margin_level",
    isActive: true,
    description: "Margin level below 150% on Main Trading account",
    threshold: 150,
    lastTriggered: new Date().toISOString(),
    createdAt: new Date().toISOString()
  },
  {
    id: 2,
    accountNumber: "87654321",
    alertType: "capital_loss",
    isActive: true,
    description: "Capital loss exceeds 25% on Test Account",
    threshold: 25,
    lastTriggered: new Date().toISOString(),
    createdAt: new Date().toISOString()
  }
];

export default function ActiveAlerts() {
  // Use mock alerts in development mode
  const activeAlerts = MOCK_ALERTS;

  const getAlertTypeIcon = (type: string) => {
    switch (type) {
      case "margin_level":
        return <AlertTriangle className="h-3 w-3 mr-1" />;
      case "capital_loss":
        return <AlertCircle className="h-3 w-3 mr-1" />;
      default:
        return <AlertTriangle className="h-3 w-3 mr-1" />;
    }
  };

  const getAlertTypeText = (type: string) => {
    switch (type) {
      case "margin_level":
        return "Margin Warning";
      case "capital_loss":
        return "Capital Loss";
      case "m2m_drop":
        return "M2M Drop";
      default:
        return type;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case "margin_level":
        return "bg-yellow-100/50 text-yellow-600";
      case "capital_loss":
        return "bg-red-100/50 text-red-600";
      case "m2m_drop":
        return "bg-orange-100/50 text-orange-600";
      default:
        return "bg-blue-100/50 text-blue-600";
    }
  };

  return (
    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <AlertTriangle className="h-5 w-5 text-yellow-500" />
        </div>
        <div className="ml-3">
          <h3 className="text-sm font-medium text-neutral-800">Active Alerts</h3>
          <div className="mt-2 flex flex-col space-y-2">
            {activeAlerts.map((alert) => (
              <div key={alert.id} className="flex items-center">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getAlertColor(alert.alertType)}`}>
                  {getAlertTypeIcon(alert.alertType)}
                  {getAlertTypeText(alert.alertType)}
                </span>
                <span className="ml-2 text-xs text-neutral-600">{alert.description}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
