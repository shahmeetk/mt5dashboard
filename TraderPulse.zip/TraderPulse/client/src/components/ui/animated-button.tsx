import { Button, ButtonProps } from "@/components/ui/button";
import { createRipple, followCursor, resetButtonTransform } from "@/lib/button-interactions";
import { cn } from "@/lib/utils";
import "@/components/ui/button-effects.css";

type AnimatedButtonVariant = 
  | "ripple" 
  | "scale" 
  | "glow" 
  | "icon-slide" 
  | "gradient" 
  | "tilt" 
  | "border"
  | "none";

interface AnimatedButtonProps extends ButtonProps {
  animationVariant?: AnimatedButtonVariant;
  iconPosition?: "left" | "right";
}

export function AnimatedButton({
  children,
  className,
  animationVariant = "scale",
  iconPosition = "left",
  ...props
}: AnimatedButtonProps) {
  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (animationVariant === "tilt") {
      followCursor(e);
    }
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (animationVariant === "tilt") {
      resetButtonTransform(e);
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Execute the ripple effect if the variant is ripple
    if (animationVariant === "ripple") {
      createRipple(e);
    }
    
    // Call the original onClick handler if it exists
    if (props.onClick) {
      props.onClick(e);
    }
  };

  // Create an array of class names based on the animation variant
  const animationClasses = [
    "btn-transition",
    animationVariant === "scale" && "btn-scale btn-push",
    animationVariant === "glow" && "btn-scale btn-glow",
    animationVariant === "icon-slide" && "btn-icon-slide",
    animationVariant === "gradient" && "btn-gradient btn-bright",
    animationVariant === "border" && "btn-border",
    animationVariant === "ripple" && "btn-ripple",
  ];

  return (
    <Button
      className={cn(...animationClasses.filter(Boolean), className)}
      onClick={handleClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      {...props}
    >
      {children}
    </Button>
  );
}