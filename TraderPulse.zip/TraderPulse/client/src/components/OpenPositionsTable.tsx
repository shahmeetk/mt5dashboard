import { useState } from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from "@/components/ui/pagination";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mt5Position, Mt5AccountData } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface OpenPositionsTableProps {
  positions: Mt5Position[];
  isLoading: boolean;
  accounts: Mt5AccountData[];
}

export default function OpenPositionsTable({ positions, isLoading, accounts }: OpenPositionsTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [accountFilter, setAccountFilter] = useState("all");
  const itemsPerPage = 5;
  
  // Filter positions by search term and account
  const filteredPositions = positions.filter(position => {
    const matchesSearch = position.symbol.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAccount = accountFilter === "all" || position.accountNumber === accountFilter;
    return matchesSearch && matchesAccount;
  });
  
  // Calculate pagination
  const totalPages = Math.ceil(filteredPositions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedPositions = filteredPositions.slice(startIndex, startIndex + itemsPerPage);
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };
  
  const formatPercent = (value: number) => {
    return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden mb-6">
      <div className="p-4 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h2 className="font-semibold text-neutral-800">Open Positions</h2>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <Select value={accountFilter} onValueChange={setAccountFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Accounts" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Accounts</SelectItem>
              {accounts.map(account => (
                <SelectItem key={account.accountNumber} value={account.accountNumber}>
                  {account.accountName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search symbol..." 
              className="w-full sm:w-40"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center p-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead>Account</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Volume</TableHead>
                  <TableHead>Open Price</TableHead>
                  <TableHead>Current Price</TableHead>
                  <TableHead>P/L</TableHead>
                  <TableHead>P/L %</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedPositions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <p className="text-muted-foreground">No positions match your search criteria</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedPositions.map((position) => (
                    <TableRow key={`${position.accountNumber}-${position.ticket}`} className="hover:bg-neutral-50">
                      <TableCell className="font-medium">{position.symbol}</TableCell>
                      <TableCell className="text-neutral-600">{position.accountName}</TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                          position.type === 'BUY' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {position.type}
                        </span>
                      </TableCell>
                      <TableCell className="font-mono">{position.volume.toFixed(2)}</TableCell>
                      <TableCell className="font-mono">{position.openPrice.toFixed(position.symbol.includes('JPY') ? 3 : 5)}</TableCell>
                      <TableCell className="font-mono">{position.currentPrice.toFixed(position.symbol.includes('JPY') ? 3 : 5)}</TableCell>
                      <TableCell className={`font-mono ${position.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {position.profit >= 0 ? '+' : ''}{formatCurrency(position.profit)}
                      </TableCell>
                      <TableCell className={position.profitPercent >= 0 ? 'text-green-600' : 'text-red-600'}>
                        {formatPercent(position.profitPercent)}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          
          {totalPages > 1 && (
            <div className="bg-neutral-50 px-4 py-3 border-t border-neutral-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-neutral-700">
                    Showing <span className="font-medium">{startIndex + 1}</span> to{" "}
                    <span className="font-medium">{Math.min(startIndex + itemsPerPage, filteredPositions.length)}</span> of{" "}
                    <span className="font-medium">{filteredPositions.length}</span> positions
                  </p>
                </div>
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                        disabled={currentPage === 1}
                      />
                    </PaginationItem>
                    
                    {[...Array(totalPages)].map((_, i) => (
                      <PaginationItem key={i}>
                        <PaginationLink
                          onClick={() => setCurrentPage(i + 1)}
                          isActive={currentPage === i + 1}
                        >
                          {i + 1}
                        </PaginationLink>
                      </PaginationItem>
                    ))}
                    
                    <PaginationItem>
                      <PaginationNext 
                        onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                        disabled={currentPage === totalPages}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
