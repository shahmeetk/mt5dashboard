import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  LineChart, 
  LayoutDashboard, 
  UserCog, 
  AlertTriangle, 
  History, 
  Settings, 
  LogOut,
  X
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import Mt5ConnectionStatus from "@/components/Mt5ConnectionStatus";

interface SidebarProps {
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

// Mock user for development mode
const MOCK_USER = {
  username: "devuser",
  displayName: "Dev User",
  email: "dev@example.com"
};

export default function Sidebar({ isMobileOpen, setIsMobileOpen }: SidebarProps) {
  const [location] = useLocation();
  const [isMobile, setIsMobile] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const { toast } = useToast();

  // Check if mobile on mount and when window resizes
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    return () => {
      window.removeEventListener('resize', checkIfMobile);
    };
  }, []);

  // Close mobile sidebar when clicking a link on mobile
  const handleLinkClick = () => {
    if (isMobile) {
      setIsMobileOpen(false);
    }
  };

  // Handle mock logout
  const handleLogout = () => {
    setIsLoggingOut(true);
    
    // Simulate logout delay
    setTimeout(() => {
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
      window.location.href = "/auth";
    }, 1000);
  };

  // Get initials for avatar from mock user
  const getInitials = () => {
    if (MOCK_USER.displayName) {
      return MOCK_USER.displayName
        .split(' ')
        .map(name => name[0])
        .slice(0, 2)
        .join('')
        .toUpperCase();
    }
    
    return MOCK_USER.username.substring(0, 2).toUpperCase();
  };

  const sidebarClass = isMobile
    ? `fixed inset-y-0 left-0 z-40 w-64 transform ${
        isMobileOpen ? "translate-x-0" : "-translate-x-full"
      } transition-transform duration-300 ease-in-out bg-white border-r border-neutral-200`
    : "w-64 bg-white border-r border-neutral-200 h-full";

  return (
    <aside className={sidebarClass}>
      <div className="h-full flex flex-col">
        {/* Sidebar Header - Logo */}
        <div className="p-4 border-b border-neutral-200 flex flex-col space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <LineChart className="h-5 w-5 text-primary" />
              <h1 className="text-lg font-semibold text-primary">MT5 Monitor</h1>
            </div>
            {isMobile && (
              <Button variant="ghost" size="sm" className="lg:hidden" onClick={() => setIsMobileOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            )}
          </div>
          
          {/* Connection Status (visible on desktop only) */}
          <div className={`${isMobile ? 'hidden' : 'block'}`}>
            <Mt5ConnectionStatus />
          </div>
        </div>
        
        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-3">
            <li>
              <div 
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === '/' 
                    ? 'bg-primary text-white' 
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
                onClick={() => {
                  handleLinkClick();
                  window.location.href = '/';
                }}
              >
                <LayoutDashboard className="mr-3 h-5 w-5" />
                Dashboard
              </div>
            </li>
            <li>
              <div 
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === '/account-management' 
                    ? 'bg-primary text-white' 
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
                onClick={() => {
                  handleLinkClick();
                  window.location.href = '/account-management';
                }}
              >
                <UserCog className="mr-3 h-5 w-5" />
                Account Management
              </div>
            </li>
            <li>
              <div 
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === '/alerts-configuration' 
                    ? 'bg-primary text-white' 
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
                onClick={() => {
                  handleLinkClick();
                  window.location.href = '/alerts-configuration';
                }}
              >
                <AlertTriangle className="mr-3 h-5 w-5" />
                Alerts Configuration
              </div>
            </li>
            <li>
              <div 
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === '/history' 
                    ? 'bg-primary text-white' 
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
                onClick={() => {
                  handleLinkClick();
                  window.location.href = '/history';
                }}
              >
                <History className="mr-3 h-5 w-5" />
                History
              </div>
            </li>
            <li>
              <div 
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer ${
                  location === '/settings' 
                    ? 'bg-primary text-white' 
                    : 'text-neutral-700 hover:bg-neutral-100'
                }`}
                onClick={() => {
                  handleLinkClick();
                  window.location.href = '/settings';
                }}
              >
                <Settings className="mr-3 h-5 w-5" />
                Settings
              </div>
            </li>
          </ul>
        </nav>
        
        {/* User Profile Section */}
        <div className="border-t border-neutral-200 p-4">
          <div className="flex items-center">
            <Avatar className="h-8 w-8 mr-3">
              <AvatarImage src="" alt={MOCK_USER.username} />
              <AvatarFallback>{getInitials()}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium text-neutral-800">{MOCK_USER.displayName}</p>
              <p className="text-xs text-neutral-500">Trader</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="mt-3 w-full justify-center"
            onClick={handleLogout}
            disabled={isLoggingOut}
          >
            <LogOut className="mr-2 h-4 w-4" />
            {isLoggingOut ? "Signing out..." : "Sign Out"}
          </Button>
        </div>
      </div>
    </aside>
  );
}
