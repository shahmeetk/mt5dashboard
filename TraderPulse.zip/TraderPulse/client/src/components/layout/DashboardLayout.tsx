import { ReactNode } from "react";
import { Link } from "wouter";
import { useLocation } from "wouter";
import { 
  Home, 
  BarChart3, 
  Bell, 
  CreditCard, 
  Settings, 
  User,
  LogOut,
  Menu,
  X,
  AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { AnimatedButton } from "@/components/ui/animated-button";
import { Separator } from "@/components/ui/separator";
import { 
  Sheet, 
  SheetContent, 
  SheetDescription, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from "@/components/ui/sheet";
import Mt5ConnectionStatus from "@/components/Mt5ConnectionStatus";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { useIsMobile } from "@/hooks/use-mobile";

interface DashboardLayoutProps {
  children: ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [location] = useLocation();
  const isMobile = useIsMobile();
  const { user, logoutMutation } = useAuth();
  
  const navItems = [
    {
      label: "User Dashboard",
      icon: <Home className="h-4 w-4 mr-2" />,
      href: "/",
      isActive: location === "/"
    },
    {
      label: "Broker Dashboard",
      icon: <BarChart3 className="h-4 w-4 mr-2" />,
      href: "/broker-dashboard",
      isActive: location === "/broker-dashboard"
    },
    {
      label: "Account Management",
      icon: <CreditCard className="h-4 w-4 mr-2" />,
      href: "/account-management",
      isActive: location === "/account-management"
    },
    {
      label: "Alerts Configuration",
      icon: <Bell className="h-4 w-4 mr-2" />,
      href: "/alerts-configuration",
      isActive: location === "/alerts-configuration"
    },
    {
      label: "Settings",
      icon: <Settings className="h-4 w-4 mr-2" />,
      href: "/settings",
      isActive: location === "/settings"
    }
  ];
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const renderNavItems = () => {
    return navItems.map((item) => (
      <Link key={item.href} href={item.href}>
        {item.isActive ? (
          <span 
            className="flex items-center py-2 px-3 text-sm font-medium rounded-md cursor-pointer w-full bg-primary/10 text-primary"
          >
            {item.icon}
            {item.label}
          </span>
        ) : (
          <span 
            className={cn(
              "flex items-center py-2 px-3 text-sm font-medium rounded-md cursor-pointer w-full",
              "text-neutral-600 hover:bg-neutral-100 btn-transition btn-icon-slide"
            )}
          >
            {item.icon}
            {item.label}
          </span>
        )}
      </Link>
    ));
  };
  
  // Mobile navigation with slide-in drawer
  const mobileNav = (
    <Sheet>
      <SheetTrigger asChild>
        <AnimatedButton 
          variant="outline" 
          size="icon" 
          className="md:hidden"
          animationVariant="scale"
        >
          <Menu className="h-5 w-5" />
        </AnimatedButton>
      </SheetTrigger>
      <SheetContent side="left" className="w-64">
        <SheetHeader className="mb-6">
          <SheetTitle>MT5 Dashboard</SheetTitle>
          <SheetDescription>
            Monitor your accounts and positions
          </SheetDescription>
        </SheetHeader>
        <div className="flex flex-col space-y-1">
          {renderNavItems()}
        </div>
        <Separator className="my-4" />
        <div className="space-y-1">
          <div className="flex items-center py-2 px-3 text-sm font-medium">
            <User className="h-4 w-4 mr-2" />
            {user?.displayName || user?.username || "User"}
          </div>
          <AnimatedButton 
            variant="outline"
            className="justify-start text-red-600 hover:text-red-600 hover:bg-red-50 hover:border-red-200 w-full"
            onClick={handleLogout}
            animationVariant="ripple"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </AnimatedButton>
        </div>
      </SheetContent>
    </Sheet>
  );
  
  // Desktop sidebar
  const desktopNav = (
    <div className="hidden md:flex md:flex-col md:w-64 md:fixed md:inset-y-0 border-r border-neutral-200">
      <div className="flex flex-col flex-grow px-4 py-5 overflow-y-auto">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">MT5 Dashboard</h1>
        </div>
        
        <div className="mt-6 flex flex-col space-y-1">
          {renderNavItems()}
        </div>
        
        <div className="mt-auto">
          <Separator className="my-4" />
          <Mt5ConnectionStatus />
          <Separator className="my-4" />
          
          <div className="flex flex-col space-y-2">
            <div className="flex items-center py-2 text-sm font-medium">
              <User className="h-4 w-4 mr-2" />
              {user?.displayName || user?.username || "User"}
            </div>
            <AnimatedButton 
              variant="outline" 
              className="justify-start text-red-600 hover:text-red-600 hover:bg-red-50 hover:border-red-200"
              onClick={handleLogout}
              animationVariant="ripple"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </AnimatedButton>
          </div>
        </div>
      </div>
    </div>
  );
  
  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Desktop navigation */}
      {desktopNav}
      
      {/* Mobile header */}
      <div className="sticky top-0 z-30 md:hidden flex items-center justify-between p-4 bg-white border-b border-neutral-200">
        {mobileNav}
        <h1 className="text-xl font-bold">MT5 Dashboard</h1>
        <Mt5ConnectionStatus compact={true} />
      </div>
      
      {/* Main content */}
      <div className="md:pl-64">
        {children}
      </div>
    </div>
  );
}