import { useState, useEffect } from "react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { getMt5ConnectionStatus } from "@/lib/mt5-client";
import { cn } from "@/lib/utils";

interface Mt5ConnectionStatusProps {
  compact?: boolean;
}

export default function Mt5ConnectionStatus({ compact = false }: Mt5ConnectionStatusProps) {
  const [status, setStatus] = useState<'connected' | 'connecting' | 'disconnected'>('connecting');
  const [lastChecked, setLastChecked] = useState(new Date());
  
  useEffect(() => {
    // Check initial status
    const initialStatus = getMt5ConnectionStatus();
    setStatus(initialStatus);
    
    // Set up an interval to check status periodically
    const interval = setInterval(() => {
      const currentStatus = getMt5ConnectionStatus();
      setStatus(currentStatus);
      setLastChecked(new Date());
    }, 30000); // Check every 30 seconds
    
    return () => clearInterval(interval);
  }, []);
  
  const statusStyles = {
    connected: {
      color: "text-green-600",
      bg: "bg-green-100",
      icon: "bg-green-500",
      text: "Connected"
    },
    connecting: {
      color: "text-amber-600",
      bg: "bg-amber-100",
      icon: "bg-amber-500",
      text: "Connecting"
    },
    disconnected: {
      color: "text-red-600",
      bg: "bg-red-100",
      icon: "bg-red-500",
      text: "Disconnected"
    }
  };
  
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
  };
  
  const currentStyle = statusStyles[status];
  
  if (compact) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>
            <div className={cn("p-1 rounded-full", currentStyle.bg)}>
              <div className={cn("w-2 h-2 rounded-full", currentStyle.icon)}></div>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-sm">
              MT5 is <span className={currentStyle.color}>{currentStyle.text}</span>
              <br />
              <span className="text-xs text-neutral-500">Last checked: {formatTime(lastChecked)}</span>
            </p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }
  
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center">
        <div className={cn("p-1 mr-2 rounded-full", currentStyle.bg)}>
          <div className={cn("w-2 h-2 rounded-full", currentStyle.icon)}></div>
        </div>
        <div>
          <div className="text-sm font-medium">MT5 Connection</div>
          <div className="text-xs text-neutral-500">Last checked: {formatTime(lastChecked)}</div>
        </div>
      </div>
      <Badge variant={status === 'connected' ? 'default' : 'outline'} className={currentStyle.color}>
        {currentStyle.text}
      </Badge>
    </div>
  );
}