import { Link } from "wouter";
import { ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

// Type definition for the alert
type Mt5AccountAlert = {
  id: number;
  name: string;
  alertType: string;
  threshold: number;
  isActive: boolean;
  accountId: string | null;
  description: string;
  notificationMethods: string[];
  lastTriggered: string | null;
  timeWindow: number | null;
  createdAt: string;
};

// Mock alerts for development mode
const MOCK_ALERTS: Mt5AccountAlert[] = [
  {
    id: 1,
    name: "Low Margin Alert",
    alertType: "margin_level",
    threshold: 150,
    isActive: true,
    accountId: "12345678",
    description: "Triggers when margin level drops below 150%",
    notificationMethods: ["Email", "SMS"],
    lastTriggered: new Date(Date.now() - 30 * 60000).toISOString(),
    timeWindow: null,
    createdAt: new Date().toISOString()
  },
  {
    id: 2,
    name: "Capital Loss Warning",
    alertType: "capital_loss",
    threshold: 25,
    isActive: true,
    accountId: "87654321",
    description: "Triggers when equity drops below 25% of peak value",
    notificationMethods: ["Email"],
    lastTriggered: new Date(Date.now() - 24 * 60 * 60000).toISOString(),
    timeWindow: null,
    createdAt: new Date().toISOString()
  }
];

export default function AlertConfigurationCard() {
  // Use mock alerts in development mode
  const displayedAlerts = MOCK_ALERTS;

  const getAlertDescription = (alert: Mt5AccountAlert) => {
    let description = "";
    
    switch (alert.alertType) {
      case "margin_level":
        description = `Triggers when margin level drops below ${alert.threshold}%`;
        break;
      case "capital_loss":
        description = `Triggers when equity drops below ${alert.threshold}% of peak value`;
        break;
      case "m2m_drop":
        description = `Triggers on mark-to-market drop of ${alert.threshold}% within ${alert.timeWindow || 60} min`;
        break;
      default:
        description = alert.description || "";
    }
    
    return description;
  };

  const formatLastTriggered = (date: string | null) => {
    if (!date) return "Never";
    const triggerDate = new Date(date);
    const now = new Date();
    const diffMs = now.getTime() - triggerDate.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) {
      return `${diffMins} minutes ago`;
    } else if (diffMins < 1440) {
      return `${Math.floor(diffMins / 60)} hours ago`;
    } else {
      return triggerDate.toLocaleDateString();
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-neutral-200 overflow-hidden mb-6">
      <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
        <h2 className="font-semibold text-neutral-800">Alert Configuration</h2>
        <Link href="/alerts-configuration">
          <Button size="sm" variant="outline" className="text-sm">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 mr-1">
              <path d="M12 5v14M19 12l-7 7-7-7"/>
            </svg>
            View All
          </Button>
        </Link>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {displayedAlerts.map((alert) => (
            <div key={alert.id} className="border border-neutral-200 rounded-md p-3">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="text-sm font-medium">{alert.name}</h3>
                  <p className="text-xs text-neutral-500">{getAlertDescription(alert)}</p>
                </div>
                <Link href={`/alerts-configuration`}>
                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                    <ExternalLink className="h-4 w-4" />
                    <span className="sr-only">Edit</span>
                  </Button>
                </Link>
              </div>
              <div className="bg-neutral-50 p-2 rounded-md space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-neutral-600">Threshold</span>
                  <span className="text-xs font-medium">
                    {alert.alertType === "margin_level" ? `${alert.threshold}%` : 
                     alert.alertType === "capital_loss" ? `${alert.threshold}% loss` : 
                     `${alert.threshold}% drop in ${alert.timeWindow || 60} min`}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-neutral-600">Accounts</span>
                  <span className="text-xs font-medium">{alert.accountId ? `Account #${alert.accountId}` : "All Accounts"}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-neutral-600">Notification</span>
                  <span className="text-xs font-medium">{alert.notificationMethods.join(", ")}</span>
                </div>
              </div>
              <div className="flex justify-between items-center mt-3">
                <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                  alert.isActive ? 'bg-green-100 text-green-800' : 'bg-neutral-100 text-neutral-800'
                }`}>
                  {alert.isActive ? 'Active' : 'Inactive'}
                </span>
                <span className="text-xs text-neutral-500">
                  Last triggered: {formatLastTriggered(alert.lastTriggered)}
                </span>
              </div>
            </div>
          ))}
          
          {displayedAlerts.length < 3 && (
            <Link href="/alerts-configuration" className="border border-dashed border-neutral-300 rounded-md p-6 flex flex-col items-center justify-center text-center hover:bg-neutral-50">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-primary">
                  <path d="M12 5v14M5 12h14"/>
                </svg>
              </div>
              <h3 className="text-sm font-medium text-neutral-800">Add New Alert</h3>
              <p className="text-xs text-neutral-500 mt-1">Configure custom alerts for your MT5 accounts</p>
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
