import { Link } from "wouter";

export default function AddAccountCard() {
  return (
    <Link href="/account-management">
      <div className="bg-white border border-neutral-300 border-dashed rounded-lg p-6 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-neutral-50 h-full">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-3">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-primary">
            <path d="M12 5v14M5 12h14"/>
          </svg>
        </div>
        <h3 className="text-sm font-medium text-neutral-800">Add New MT5 Account</h3>
        <p className="text-xs text-neutral-500 mt-1 max-w-xs">Connect a new MetaTrader 5 account using investor (read-only) credentials</p>
      </div>
    </Link>
  );
}
