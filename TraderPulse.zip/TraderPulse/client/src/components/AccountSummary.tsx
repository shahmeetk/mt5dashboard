import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  BarChart2, 
  Scale, 
  PieChart, 
  Activity, 
  AlertTriangle, 
  Shield, 
  LineChart 
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface AccountSummaryProps {
  totalBalance: number;
  totalEquity: number;
  totalMargin: number;
  totalProfit: number;
  balanceChange: number;
  equityChange: number;
  profitChange: number;
}

export default function AccountSummary({
  totalBalance,
  totalEquity,
  totalMargin,
  totalProfit,
  balanceChange,
  equityChange,
  profitChange
}: AccountSummaryProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  // Calculate the overall portfolio health status
  const calculatePortfolioHealth = () => {
    // Calculate overall margin level
    const marginLevel = totalMargin > 0 
      ? (totalEquity / totalMargin) * 100 
      : 1000; // If no margin used, health is excellent
    
    // Calculate equity to balance ratio
    const equityRatio = (totalEquity / totalBalance) * 100;
    
    // Create an aggregate health score (0-100) based on multiple factors
    let healthScore = 0;
    
    // Factor 1: Margin level (40% of score)
    if (marginLevel > 500) healthScore += 40;
    else if (marginLevel > 300) healthScore += 30;
    else if (marginLevel > 200) healthScore += 20;
    else if (marginLevel > 100) healthScore += 10;
    
    // Factor 2: Equity to balance ratio (30% of score)
    if (equityRatio >= 100) healthScore += 30;
    else if (equityRatio >= 95) healthScore += 25;
    else if (equityRatio >= 90) healthScore += 20;
    else if (equityRatio >= 80) healthScore += 10;
    else if (equityRatio >= 70) healthScore += 5;
    
    // Factor 3: Profit change (30% of score)
    if (profitChange > 5) healthScore += 30;
    else if (profitChange > 2) healthScore += 25;
    else if (profitChange > 0) healthScore += 20;
    else if (profitChange > -3) healthScore += 15;
    else if (profitChange > -5) healthScore += 10;
    else if (profitChange > -10) healthScore += 5;
    
    // Map score to status
    if (healthScore >= 70) return "healthy";
    else if (healthScore >= 40) return "warning";
    else return "danger";
  };

  const getHealthStatusDetails = (status: string) => {
    const marginLevel = totalMargin > 0 
      ? (totalEquity / totalMargin) * 100 
      : 1000;
      
    switch (status) {
      case 'healthy':
        return {
          icon: <Shield className="h-5 w-5 mr-2" />,
          color: 'bg-green-100 text-green-600 border-green-200',
          hoverColor: 'hover:bg-green-50',
          pulseColor: 'bg-green-400',
          borderColor: 'border-green-200',
          shadowColor: 'shadow-green-100',
          label: 'Healthy',
          description: 'Your portfolio is in good standing with adequate margin and balanced risk.',
          marginText: marginLevel > 500 
            ? 'Excellent overall margin level'
            : 'Good overall margin level'
        };
      case 'warning':
        return {
          icon: <AlertTriangle className="h-5 w-5 mr-2" />,
          color: 'bg-yellow-100 text-yellow-600 border-yellow-200',
          hoverColor: 'hover:bg-yellow-50',
          pulseColor: 'bg-yellow-400',
          borderColor: 'border-yellow-200',
          shadowColor: 'shadow-yellow-100',
          label: 'Warning',
          description: 'Your portfolio requires attention. Margin levels or metrics are approaching risk thresholds.',
          marginText: 'Portfolio margin levels need attention'
        };
      default:
        return {
          icon: <Activity className="h-5 w-5 mr-2" />,
          color: 'bg-red-100 text-red-600 border-red-200',
          hoverColor: 'hover:bg-red-50',
          pulseColor: 'bg-red-400',
          borderColor: 'border-red-200',
          shadowColor: 'shadow-red-100',
          label: 'Risk',
          description: 'Your portfolio is at high risk. Immediate action may be required to prevent margin calls.',
          marginText: 'Critical portfolio margin level'
        };
    }
  };

  const portfolioStatus = calculatePortfolioHealth();
  const healthStatus = getHealthStatusDetails(portfolioStatus);
  
  // Calculate overall margin level percentage
  const marginLevel = totalMargin > 0 
    ? (totalEquity / totalMargin) * 100 
    : 1000;
  
  // Calculate equity to balance ratio
  const equityRatio = (totalEquity / totalBalance) * 100;
  const equityStatus = equityRatio >= 100 
    ? 'text-green-600' 
    : equityRatio >= 90 
      ? 'text-yellow-600' 
      : 'text-red-600';

  return (
    <div className={`bg-white rounded-lg shadow p-5 mb-6 border ${healthStatus.borderColor}`}>
      <div className="flex flex-wrap items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Overall Portfolio Health</h2>
        
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className={`px-3 py-2 rounded-md flex items-center cursor-help ${healthStatus.color} ${healthStatus.hoverColor} transition-colors duration-200 border shadow-sm`}>
                <div className="relative mr-1">
                  <div className="absolute -top-1 -left-1 w-2 h-2 rounded-full animate-ping opacity-75 transition-opacity duration-1000 ease-in-out" style={{ backgroundColor: portfolioStatus === 'danger' ? '#f87171' : portfolioStatus === 'warning' ? '#facc15' : '#4ade80' }}></div>
                  <div className={`w-2 h-2 rounded-full ${healthStatus.pulseColor}`}></div>
                </div>
                {healthStatus.icon}
                <span className="text-sm font-medium capitalize whitespace-nowrap">{healthStatus.label}</span>
              </div>
            </TooltipTrigger>
            <TooltipContent side="right" className="max-w-xs">
              <div className="space-y-2">
                <p className="font-medium">{healthStatus.label} Portfolio Status</p>
                <p className="text-sm text-neutral-600">{healthStatus.description}</p>
                <ul className="text-xs text-neutral-500 pl-5 list-disc space-y-1">
                  <li>Overall Margin Level: {marginLevel.toFixed(2)}% ({healthStatus.marginText})</li>
                  <li>Equity Ratio: {equityRatio.toFixed(2)}% of total balance</li>
                  <li>P/L Change: {profitChange >= 0 ? '+' : ''}{profitChange}%</li>
                </ul>
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <div className={`bg-neutral-50 p-4 rounded-md shadow-sm transition-all duration-200 ${healthStatus.shadowColor}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <p className="text-sm font-medium text-neutral-600 mr-1">Total Balance</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Total funds across all accounts without including open positions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <DollarSign className="h-5 w-5 text-primary" />
          </div>
          <p className="text-2xl font-semibold font-mono mt-2">{formatCurrency(totalBalance)}</p>
          <div className={`flex items-center mt-1 ${balanceChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {balanceChange >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
            <span className="text-xs font-medium">{Math.abs(balanceChange)}% today</span>
          </div>
        </div>
        
        <div className={`bg-neutral-50 p-4 rounded-md shadow-sm transition-all duration-200 ${healthStatus.shadowColor}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <p className="text-sm font-medium text-neutral-600 mr-1">Total Equity</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Balance + floating P/L from all open positions across accounts</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <BarChart2 className="h-5 w-5 text-primary" />
          </div>
          <p className={`text-2xl font-semibold font-mono mt-2 ${equityStatus}`}>{formatCurrency(totalEquity)}</p>
          <div className={`flex items-center mt-1 ${equityChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {equityChange >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
            <span className="text-xs font-medium">{Math.abs(equityChange)}% today</span>
          </div>
        </div>
        
        <div className={`bg-neutral-50 p-4 rounded-md shadow-sm transition-all duration-200 ${healthStatus.shadowColor}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <p className="text-sm font-medium text-neutral-600 mr-1">Total Margin</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Collateral required to maintain all open positions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <Scale className="h-5 w-5 text-primary" />
          </div>
          <p className="text-2xl font-semibold font-mono mt-2">{formatCurrency(totalMargin)}</p>
          <div className="flex items-center mt-1">
            <span className={`text-xs font-medium ${
              marginLevel > 500 ? 'text-green-600' : 
              marginLevel > 300 ? 'text-green-500' : 
              marginLevel > 200 ? 'text-yellow-600' :
              marginLevel > 100 ? 'text-orange-600' : 'text-red-600'
            }`}>
              {marginLevel.toFixed(2)}% margin level
            </span>
          </div>
        </div>
        
        <div className={`bg-neutral-50 p-4 rounded-md shadow-sm transition-all duration-200 ${healthStatus.shadowColor}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <p className="text-sm font-medium text-neutral-600 mr-1">Open P/L</p>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                        <line x1="12" y1="17" x2="12.01" y2="17" />
                      </svg>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Current profit/loss from all open positions</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <PieChart className="h-5 w-5 text-primary" />
          </div>
          <div className="flex items-center mt-2">
            <LineChart className={`h-4 w-4 mr-1 ${totalProfit >= 0 ? 'text-green-500' : 'text-red-500'}`} />
            <p className={`text-2xl font-semibold font-mono ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {totalProfit >= 0 ? '+' : ''}{formatCurrency(totalProfit)}
            </p>
          </div>
          <div className={`flex items-center mt-1 ${profitChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {profitChange >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
            <span className="text-xs font-medium">{Math.abs(profitChange)}% return</span>
          </div>
        </div>
      </div>
    </div>
  );
}
