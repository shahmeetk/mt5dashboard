import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { 
  Loader2, 
  UserPlus, 
  UserMinus, 
  UserCheck, 
  LogOut, 
  ArrowLeft, 
  Shield, 
  UserCog,
  Users,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AdminPage() {
  const { user, logoutMutation } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("users");
  const [newUserDialogOpen, setNewUserDialogOpen] = useState(false);
  const [newUserData, setNewUserData] = useState({
    username: "",
    email: "",
    password: "",
    displayName: "",
    isAdmin: false
  });
  
  // Redirect if not admin
  useEffect(() => {
    if (user && !user.isAdmin) {
      navigate("/");
      toast({
        title: "Access Denied",
        description: "You don't have permission to access this page.",
        variant: "destructive"
      });
    }
  }, [user, navigate, toast]);
  
  // Fetch users
  const { 
    data: users = [], 
    isLoading: isLoadingUsers,
    error: usersError
  } = useQuery({
    queryKey: ["api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users");
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      return response.json() as Promise<User[]>;
    },
    enabled: !!user?.isAdmin
  });
  
  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (newUser: typeof newUserData) => {
      const response = await fetch("/api/users", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newUser)
      });
      if (!response.ok) {
        throw new Error('Failed to create user');
      }
      return response.json() as Promise<User>;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User created successfully"
      });
      setNewUserDialogOpen(false);
      setNewUserData({
        username: "",
        email: "",
        password: "",
        displayName: "",
        isAdmin: false
      });
      queryClient.invalidateQueries({ queryKey: ["api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create user: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Update user mutation (toggle active status)
  const updateUserMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number, isActive: boolean }) => {
      const response = await fetch(`/api/users/${id}`, {
        method: "PATCH",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ isActive })
      });
      if (!response.ok) {
        throw new Error('Failed to update user status');
      }
      return response.json() as Promise<User>;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User status updated"
      });
      queryClient.invalidateQueries({ queryKey: ["api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update user: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Toggle admin status mutation
  const toggleAdminMutation = useMutation({
    mutationFn: async ({ id, isAdmin }: { id: number, isAdmin: boolean }) => {
      const response = await fetch(`/api/users/${id}`, {
        method: "PATCH",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ isAdmin })
      });
      if (!response.ok) {
        throw new Error('Failed to update admin status');
      }
      const data = await response.json();
      return data;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Admin status updated"
      });
      queryClient.invalidateQueries({ queryKey: ["api/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update admin status: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const handleCreateUser = () => {
    if (!newUserData.username || !newUserData.email || !newUserData.password) {
      toast({
        title: "Validation Error",
        description: "Username, email and password are required",
        variant: "destructive"
      });
      return;
    }
    
    createUserMutation.mutate(newUserData);
  };
  
  const handleToggleUserStatus = (id: number, currentStatus: boolean) => {
    updateUserMutation.mutate({ id, isActive: !currentStatus });
  };
  
  const handleToggleAdminStatus = (id: number, currentStatus: boolean) => {
    toggleAdminMutation.mutate({ id, isAdmin: !currentStatus });
  };
  
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!user.isAdmin) {
    return null; // Will redirect via useEffect
  }
  
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background border-b border-neutral-200 shadow-sm px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Shield className="h-6 w-6 text-primary mr-2" />
            <h1 className="text-xl font-semibold">Admin Panel</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              onClick={() => navigate("/")}
              className="flex items-center gap-1"
            >
              <ArrowLeft size={16} />
              <span>Back to Dashboard</span>
            </Button>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              className="flex items-center gap-1"
            >
              <LogOut size={16} />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="users" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="users" className="flex items-center gap-1">
              <Users size={16} />
              <span>Manage Users</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>Manage system users and their permissions</CardDescription>
                  </div>
                  <Dialog open={newUserDialogOpen} onOpenChange={setNewUserDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="flex items-center gap-1">
                        <UserPlus size={16} />
                        <span>Add User</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add New User</DialogTitle>
                        <DialogDescription>
                          Create a new user account. All fields are required.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="username">Username</Label>
                          <Input 
                            id="username" 
                            value={newUserData.username}
                            onChange={(e) => setNewUserData({...newUserData, username: e.target.value})}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="email">Email</Label>
                          <Input 
                            id="email" 
                            type="email"
                            value={newUserData.email}
                            onChange={(e) => setNewUserData({...newUserData, email: e.target.value})}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="password">Password</Label>
                          <Input 
                            id="password" 
                            type="password"
                            value={newUserData.password}
                            onChange={(e) => setNewUserData({...newUserData, password: e.target.value})}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="displayName">Display Name</Label>
                          <Input 
                            id="displayName" 
                            value={newUserData.displayName}
                            onChange={(e) => setNewUserData({...newUserData, displayName: e.target.value})}
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch 
                            id="admin-rights" 
                            checked={newUserData.isAdmin}
                            onCheckedChange={(checked) => setNewUserData({...newUserData, isAdmin: checked})}
                          />
                          <Label htmlFor="admin-rights">Admin Rights</Label>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setNewUserDialogOpen(false)}>Cancel</Button>
                        <Button 
                          onClick={handleCreateUser}
                          disabled={createUserMutation.isPending}
                        >
                          {createUserMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Creating...
                            </>
                          ) : (
                            "Create User"
                          )}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingUsers ? (
                  <div className="flex items-center justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : usersError ? (
                  <div className="text-center text-red-500 p-4">
                    Error loading users: {usersError.message}
                  </div>
                ) : (
                  <Table>
                    <TableCaption>List of all system users</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Display Name</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Admin</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Array.isArray(users) && users.map((userData: User) => (
                        <TableRow key={userData.id}>
                          <TableCell>{userData.id}</TableCell>
                          <TableCell>{userData.username}</TableCell>
                          <TableCell>{userData.email}</TableCell>
                          <TableCell>{userData.displayName}</TableCell>
                          <TableCell>{userData.createdAt ? (typeof userData.createdAt === 'string' ? new Date(userData.createdAt).toLocaleDateString() : userData.createdAt.toLocaleDateString()) : '-'}</TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              className={`${userData.isAdmin ? 'text-primary' : 'text-muted-foreground'}`}
                              onClick={() => handleToggleAdminStatus(userData.id, !!userData.isAdmin)}
                              disabled={userData.id === user?.id} // Can't change own admin status
                            >
                              {userData.isAdmin ? (
                                <Shield className="h-4 w-4" />
                              ) : (
                                <UserCog className="h-4 w-4" />
                              )}
                            </Button>
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              userData.isActive 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {userData.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleToggleUserStatus(userData.id, !!userData.isActive)}
                              disabled={userData.id === user?.id} // Can't deactivate self
                              className={userData.isActive ? 'text-red-500' : 'text-green-500'}
                            >
                              {userData.isActive ? (
                                <UserMinus className="h-4 w-4" />
                              ) : (
                                <UserCheck className="h-4 w-4" />
                              )}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                      {Array.isArray(users) && users.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center">
                            No users found
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}