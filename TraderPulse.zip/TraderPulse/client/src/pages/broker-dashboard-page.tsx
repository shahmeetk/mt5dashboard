import { useEffect, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useToast } from "@/hooks/use-toast";
import { fetchMt5Accounts, fetchMt5Positions, subscribeToMt5AccountUpdates, subscribeToMt5PositionUpdates } from "@/lib/mt5-client";
import { Mt5AccountData, Mt5Position } from "@shared/schema";
import AccountCard from "@/components/AccountCard";
import OpenPositionsTable from "@/components/OpenPositionsTable";
import AccountSummary from "@/components/AccountSummary";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle, BarChart3, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AnimatedButton } from "@/components/ui/animated-button";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function BrokerDashboardPage() {
  const [accounts, setAccounts] = useState<Mt5AccountData[]>([]);
  const [positions, setPositions] = useState<Mt5Position[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedBroker, setSelectedBroker] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Group accounts by broker
  const brokerGroups = accounts.reduce<Record<string, Mt5AccountData[]>>((groups, account) => {
    const broker = account.brokerName;
    if (!groups[broker]) {
      groups[broker] = [];
    }
    groups[broker].push(account);
    return groups;
  }, {});
  
  const brokerNames = Object.keys(brokerGroups);
  
  // Set first broker as selected if none selected
  useEffect(() => {
    if (brokerNames.length > 0 && !selectedBroker) {
      setSelectedBroker(brokerNames[0]);
    }
  }, [brokerNames, selectedBroker]);
  
  // Filter positions based on selected broker
  const filteredPositions = selectedBroker
    ? positions.filter(position => {
        const accountNumber = position.accountNumber;
        return accounts.some(account => 
          account.accountNumber === accountNumber && account.brokerName === selectedBroker
        );
      })
    : positions;
  
  // Calculate summary stats for the broker
  const calculateBrokerSummary = (broker: string) => {
    const brokerAccounts = brokerGroups[broker] || [];
    
    return brokerAccounts.reduce(
      (summary, account) => {
        summary.totalBalance += account.balance;
        summary.totalEquity += account.equity;
        summary.totalMargin += account.margin;
        summary.totalProfit += account.profit;
        return summary;
      },
      { totalBalance: 0, totalEquity: 0, totalMargin: 0, totalProfit: 0 }
    );
  };
  
  // Initialize data
  useEffect(() => {
    const userId = "current-user"; // In a real app, this would come from auth context
    
    const loadInitialData = async () => {
      setIsLoading(true);
      try {
        // Fetch initial accounts and positions
        const accountsData = await fetchMt5Accounts(userId);
        const positionsData = await fetchMt5Positions(userId);
        
        setAccounts(accountsData);
        setPositions(positionsData);
      } catch (error) {
        console.error("Error loading MT5 data:", error);
        toast({
          title: "Data Loading Error",
          description: "Could not load MT5 account data. Please try again later.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadInitialData();
    
    // Subscribe to real-time updates
    const unsubscribeAccounts = subscribeToMt5AccountUpdates(userId, (updatedAccounts) => {
      setAccounts(updatedAccounts);
    });
    
    const unsubscribePositions = subscribeToMt5PositionUpdates(userId, (updatedPositions) => {
      setPositions(updatedPositions);
    });
    
    return () => {
      unsubscribeAccounts();
      unsubscribePositions();
    };
  }, [toast]);
  
  const formatDateTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(date);
  };

  // Render broker tab buttons
  const renderBrokerTabs = () => {
    return (
      <TabsList className="grid grid-cols-3 mb-4">
        {brokerNames.map((broker) => (
          <TabsTrigger 
            key={broker} 
            value={broker}
            onClick={() => setSelectedBroker(broker)}
            className="text-sm"
          >
            {broker}
          </TabsTrigger>
        ))}
      </TabsList>
    );
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="container mx-auto p-4 lg:p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Broker Dashboard</h1>
            <div className="flex space-x-2">
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
            </div>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-64 w-full" />
            ))}
          </div>
          
          <Skeleton className="h-80 w-full" />
        </div>
      </DashboardLayout>
    );
  }

  if (brokerNames.length === 0) {
    return (
      <DashboardLayout>
        <div className="container mx-auto p-4 lg:p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Broker Dashboard</h1>
            <Link href="/account-management">
              <AnimatedButton
                animationVariant="glow"
                className="relative"
              >
                Add Account
              </AnimatedButton>
            </Link>
          </div>
          
          <Card className="my-8">
            <CardHeader>
              <CardTitle>No MT5 Accounts Found</CardTitle>
              <CardDescription>
                You haven't added any MT5 accounts yet. Add an account to start monitoring.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/account-management">
                <AnimatedButton
                  animationVariant="glow"
                  className="relative"
                >
                  Add Your First Account
                </AnimatedButton>
              </Link>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="container mx-auto p-4 lg:p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <h1 className="text-2xl font-bold">Broker Dashboard</h1>
          <div className="flex space-x-2">
            <Link href="/">
              <AnimatedButton 
                variant="outline" 
                className="flex items-center gap-1"
                animationVariant="icon-slide"
              >
                <Users size={16} />
                <span>User View</span>
              </AnimatedButton>
            </Link>
            <Link href="/account-management">
              <AnimatedButton
                animationVariant="glow"
                className="relative"
              >
                Add Account
              </AnimatedButton>
            </Link>
          </div>
        </div>
        
        <Tabs 
          defaultValue={selectedBroker || brokerNames[0]} 
          className="w-full"
        >
          {brokerNames.length > 0 && renderBrokerTabs()}
          
          {brokerNames.map((broker) => {
            const brokerSummary = calculateBrokerSummary(broker);
            const brokerAccounts = brokerGroups[broker] || [];
            
            return (
              <TabsContent key={broker} value={broker}>
                <div className="mb-6">
                  <AccountSummary 
                    totalBalance={brokerSummary.totalBalance}
                    totalEquity={brokerSummary.totalEquity}
                    totalMargin={brokerSummary.totalMargin}
                    totalProfit={brokerSummary.totalProfit}
                    // These would need actual historical data to be accurate
                    balanceChange={0}
                    equityChange={0}
                    profitChange={0}
                  />
                </div>
                
                <h2 className="text-lg font-semibold mb-4">{broker} Accounts</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                  {brokerAccounts.map((account) => (
                    <AccountCard key={account.accountNumber} account={account} />
                  ))}
                </div>
                
                <h2 className="text-lg font-semibold mb-4">Open Positions</h2>
                <OpenPositionsTable 
                  positions={filteredPositions} 
                  isLoading={isLoading} 
                  accounts={accounts}
                />
                
                <div className="mt-4 text-xs text-neutral-500 text-right">
                  Last updated: {formatDateTime(new Date())}
                </div>
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </DashboardLayout>
  );
}