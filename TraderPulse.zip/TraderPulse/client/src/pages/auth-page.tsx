import { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { AnimatedButton } from "@/components/ui/animated-button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Login schema
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

type LoginValues = z.infer<typeof loginSchema>;

// Registration schema extends the insert schema
const registerSchema = insertUserSchema.extend({
  email: z.string().email(),
  password: z.string().min(6),
  confirmPassword: z.string().min(6),
  displayName: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type RegisterValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [isLoggingIn, setIsLoggingIn] = useState(true);
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Login form
  const loginForm = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      displayName: "",
    },
  });

  // Handle login without using the auth hook
  const onLoginSubmit = async (values: LoginValues) => {
    try {
      setIsSubmitting(true);
      const res = await apiRequest("POST", "/api/login", values);
      const user = await res.json();
      
      queryClient.setQueryData(["/api/user"], user);
      
      toast({
        title: "Login successful",
        description: `Welcome back${user.username ? `, ${user.username}` : ''}!`,
      });
      
      // Redirect to dashboard
      navigate("/");
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "An error occurred during login",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle registration without using the auth hook
  const onRegisterSubmit = async (values: RegisterValues) => {
    try {
      setIsSubmitting(true);
      // Remove confirmPassword as it's not part of our model
      const { confirmPassword, ...registerData } = values;
      
      const res = await apiRequest("POST", "/api/register", registerData);
      const user = await res.json();
      
      queryClient.setQueryData(["/api/user"], user);
      
      toast({
        title: "Registration successful",
        description: `Welcome${user.username ? `, ${user.username}` : ''}!`,
      });
      
      // Redirect to dashboard
      navigate("/");
    } catch (error: any) {
      toast({
        title: "Registration failed",
        description: error.message || "An error occurred during registration",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen">
      {/* Left column - Auth Form */}
      <div className="flex flex-col justify-center w-full p-8 md:w-1/2">
        <div className="mx-auto w-full max-w-md">
          <div className="flex items-center mb-8">
            <LineChart className="h-6 w-6 text-primary mr-2" />
            <h1 className="text-2xl font-bold text-primary">MT5 Monitor</h1>
          </div>

          <Tabs defaultValue="login" value={isLoggingIn ? "login" : "register"} onValueChange={(v) => setIsLoggingIn(v === "login")}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Sign In</CardTitle>
                  <CardDescription>
                    Enter your credentials to access your dashboard
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="you@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="******" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <AnimatedButton 
                        type="submit" 
                        className="w-full" 
                        disabled={isSubmitting}
                        animationVariant="gradient"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Signing in...
                          </>
                        ) : "Sign In"}
                      </AnimatedButton>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex flex-col items-center">
                  <p className="text-sm text-muted-foreground">
                    Don't have an account?{" "}
                    <Button variant="link" className="p-0" onClick={() => setIsLoggingIn(false)}>
                      <span className="underline">Sign up</span>
                    </Button>
                  </p>
                </CardFooter>
              </Card>
            </TabsContent>
            
            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Create Account</CardTitle>
                  <CardDescription>
                    Create a new account to get started
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="johndoe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="displayName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Display Name (optional)</FormLabel>
                            <FormControl>
                              <Input placeholder="John Doe" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="you@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="******" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirm Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="******" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <AnimatedButton 
                        type="submit" 
                        className="w-full" 
                        disabled={isSubmitting}
                        animationVariant="gradient"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating account...
                          </>
                        ) : "Create Account"}
                      </AnimatedButton>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex flex-col items-center">
                  <p className="text-sm text-muted-foreground">
                    Already have an account?{" "}
                    <Button variant="link" className="p-0" onClick={() => setIsLoggingIn(true)}>
                      <span className="underline">Sign in</span>
                    </Button>
                  </p>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Right column - Hero Image */}
      <div className="hidden md:block md:w-1/2 bg-primary">
        <div className="flex flex-col justify-center h-full p-12 text-white">
          <h1 className="text-3xl font-bold mb-4">MT5 Account Monitor</h1>
          <p className="text-xl mb-6">
            Track your MetaTrader 5 accounts in real-time from any device.
          </p>
          <ul className="space-y-3">
            <li className="flex items-center">
              <div className="mr-2 w-6 h-6 rounded-full flex items-center justify-center bg-white/20">✓</div>
              <span>Monitor multiple accounts across different brokers</span>
            </li>
            <li className="flex items-center">
              <div className="mr-2 w-6 h-6 rounded-full flex items-center justify-center bg-white/20">✓</div>
              <span>Real-time balance, equity and margin tracking</span>
            </li>
            <li className="flex items-center">
              <div className="mr-2 w-6 h-6 rounded-full flex items-center justify-center bg-white/20">✓</div>
              <span>Setup custom alerts for quick response to market changes</span>
            </li>
            <li className="flex items-center">
              <div className="mr-2 w-6 h-6 rounded-full flex items-center justify-center bg-white/20">✓</div>
              <span>View all open positions across your accounts</span>
            </li>
            <li className="flex items-center">
              <div className="mr-2 w-6 h-6 rounded-full flex items-center justify-center bg-white/20">✓</div>
              <span>Works on desktop and mobile browsers</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
