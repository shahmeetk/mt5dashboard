import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { AnimatedButton } from "@/components/ui/animated-button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Mt5AccountData } from "@shared/schema";
import { Loader2, Plus, Edit2, Trash2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

// Form schema for MT5 account
const accountSchema = z.object({
  accountName: z.string().min(3, "Account name must be at least 3 characters"),
  brokerName: z.string().min(2, "Broker name is required"),
  accountNumber: z.string().min(5, "Account number is required"),
  serverName: z.string().min(2, "Server name is required"),
  password: z.string().min(4, "Investor password is required"),
});

type AccountFormValues = z.infer<typeof accountSchema>;

export default function AccountManagementPage() {
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<Mt5AccountData | null>(null);
  const { toast } = useToast();

  // Fetch accounts
  const { data: accounts = [], isLoading } = useQuery<Mt5AccountData[]>({
    queryKey: ["/api/mt5-accounts"],
    enabled: !!user?.id,
  });

  // Form for adding/editing account
  const form = useForm<AccountFormValues>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      accountName: "",
      brokerName: "",
      accountNumber: "",
      serverName: "",
      password: "",
    },
  });

  // Add account mutation
  const addAccountMutation = useMutation({
    mutationFn: async (values: AccountFormValues) => {
      // Map password field to credentials as expected by the API
      const res = await apiRequest("POST", "/api/mt5-accounts", {
        accountName: values.accountName,
        brokerName: values.brokerName,
        accountNumber: values.accountNumber,
        serverName: values.serverName,
        credentials: values.password, // Rename password to credentials for API
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mt5-accounts"] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: "Account added",
        description: "MT5 account has been added successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add account",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update account mutation
  const updateAccountMutation = useMutation({
    mutationFn: async (values: AccountFormValues) => {
      // Only include password/credentials if it was provided
      const payload: any = {
        accountName: values.accountName,
        brokerName: values.brokerName,
        serverName: values.serverName,
      };
      
      // Only add credentials if password field was filled in
      if (values.password) {
        payload.credentials = values.password;
      }
      
      const res = await apiRequest("PATCH", `/api/mt5-accounts/${values.accountNumber}`, payload);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mt5-accounts"] });
      setIsDialogOpen(false);
      setSelectedAccount(null);
      form.reset();
      toast({
        title: "Account updated",
        description: "MT5 account has been updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update account",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Delete account mutation
  const deleteAccountMutation = useMutation({
    mutationFn: async (accountNumber: string) => {
      await apiRequest("DELETE", `/api/mt5-accounts/${accountNumber}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mt5-accounts"] });
      toast({
        title: "Account deleted",
        description: "MT5 account has been deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete account",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: AccountFormValues) => {
    if (selectedAccount) {
      updateAccountMutation.mutate(values);
    } else {
      addAccountMutation.mutate(values);
    }
  };

  // Open dialog for editing
  const handleEdit = (account: Mt5AccountData) => {
    setSelectedAccount(account);
    form.reset({
      accountName: account.accountName,
      brokerName: account.brokerName,
      accountNumber: account.accountNumber,
      serverName: account.serverName || "",
      password: "", // Don't prefill password for security
    });
    setIsDialogOpen(true);
  };

  // Open dialog for adding
  const handleAdd = () => {
    setSelectedAccount(null);
    form.reset({
      accountName: "",
      brokerName: "",
      accountNumber: "",
      serverName: "",
      password: "",
    });
    setIsDialogOpen(true);
  };

  // Handle delete
  const handleDelete = (accountNumber: string) => {
    deleteAccountMutation.mutate(accountNumber);
  };

  return (
    <DashboardLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">MT5 Account Management</h1>
          <AnimatedButton
            onClick={handleAdd}
            animationVariant="ripple"
          >
            <Plus className="mr-2 h-4 w-4" /> Add New Account
          </AnimatedButton>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Your MT5 Accounts</CardTitle>
            <CardDescription>
              Manage your MetaTrader 5 accounts connected via investor (read-only) access
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : accounts.length === 0 ? (
              <div className="text-center p-8 border-2 border-dashed border-gray-200 rounded-lg">
                <AlertCircle className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                <h3 className="font-medium text-lg mb-1">No accounts found</h3>
                <p className="text-muted-foreground mb-4">
                  You haven't added any MT5 accounts yet.
                </p>
                <AnimatedButton 
                  onClick={handleAdd}
                  animationVariant="glow"
                  className="relative"
                >
                  Add Your First Account
                </AnimatedButton>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account Name</TableHead>
                      <TableHead>Broker</TableHead>
                      <TableHead>Account Number</TableHead>
                      <TableHead>Server</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accounts.map((account) => (
                      <TableRow key={account.accountNumber}>
                        <TableCell className="font-medium">{account.accountName}</TableCell>
                        <TableCell>{account.brokerName}</TableCell>
                        <TableCell>{account.accountNumber}</TableCell>
                        <TableCell>{account.serverName || "N/A"}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                            ${account.status === 'healthy' ? 'bg-green-100 text-green-800' : 
                              account.status === 'warning' ? 'bg-yellow-100 text-yellow-800' : 
                              'bg-red-100 text-red-800'}`}>
                            {account.status === 'healthy' ? 'Connected' :
                             account.status === 'warning' ? 'Warning' : 'Error'}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <AnimatedButton 
                              variant="outline" 
                              size="sm" 
                              onClick={() => handleEdit(account)}
                              animationVariant="icon-slide"
                            >
                              <Edit2 className="h-4 w-4" />
                            </AnimatedButton>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <AnimatedButton 
                                  variant="outline" 
                                  size="sm" 
                                  className="text-red-500 hover:text-red-600"
                                  animationVariant="ripple"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </AnimatedButton>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This will remove the MT5 account "{account.accountName}" from your dashboard. 
                                    This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction asChild>
                                    <AnimatedButton 
                                      onClick={() => handleDelete(account.accountNumber)}
                                      className="bg-red-500 hover:bg-red-600"
                                      animationVariant="ripple"
                                    >
                                      Delete
                                    </AnimatedButton>
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add/Edit Account Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>{selectedAccount ? "Edit MT5 Account" : "Add MT5 Account"}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="accountName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. ICMarkets Pro" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="brokerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Broker Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. ICMarkets" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="accountNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Number</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 12345678" {...field} readOnly={!!selectedAccount} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="serverName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Server Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. ICMarkets-Live" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{selectedAccount ? "New Investor Password (leave blank to keep current)" : "Investor Password"}</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Enter investor (read-only) password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <AnimatedButton 
                    type="submit" 
                    disabled={addAccountMutation.isPending || updateAccountMutation.isPending}
                    animationVariant="gradient"
                  >
                    {(addAccountMutation.isPending || updateAccountMutation.isPending) ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {selectedAccount ? "Updating..." : "Adding..."}
                      </>
                    ) : (
                      selectedAccount ? "Update Account" : "Add Account"
                    )}
                  </AnimatedButton>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
