import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import AccountSummary from "@/components/AccountSummary";
import AccountCard from "@/components/AccountCard";
import ActiveAlerts from "@/components/ActiveAlerts";
import OpenPositionsTable from "@/components/OpenPositionsTable";
import AlertConfigurationCard from "@/components/AlertConfigurationCard";
import AddAccountCard from "@/components/AddAccountCard";
import { Mt5AccountData, Mt5Position } from "@shared/schema";
import { RefreshCw, Loader2, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AnimatedButton } from "@/components/ui/animated-button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { fetchMt5Accounts, fetchMt5Positions, subscribeToMt5AccountUpdates, subscribeToMt5PositionUpdates, testMt5Connection } from "@/lib/mt5-client";
import { useToast } from "@/hooks/use-toast";

export default function DashboardPage() {
  const [updateInterval, setUpdateInterval] = useState("5"); // seconds
  const [accounts, setAccounts] = useState<Mt5AccountData[]>([]);
  const [positions, setPositions] = useState<Mt5Position[]>([]);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingPositions, setIsLoadingPositions] = useState(true);
  const [isManualRefreshing, setIsManualRefreshing] = useState(false);
  const [selectedUser, setSelectedUser] = useState<string>("current-user"); // For multi-user view in admin panel
  const { toast } = useToast();

  // Initialize data
  useEffect(() => {
    const loadInitialData = async () => {
      try {
        // Test MT5 connection first
        const connectionTest = await testMt5Connection();
        if (!connectionTest.connected) {
          toast({
            title: "MT5 Connection Issue",
            description: connectionTest.message,
            variant: "destructive",
          });
        }
        
        // Fetch initial accounts and positions
        const accountsData = await fetchMt5Accounts(selectedUser);
        const positionsData = await fetchMt5Positions(selectedUser);
        
        setAccounts(accountsData);
        setPositions(positionsData);
        setLastUpdated(new Date());
      } catch (error) {
        console.error("Error loading MT5 data:", error);
        toast({
          title: "Data Loading Error",
          description: "Could not load MT5 account data. Please try again later.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
        setIsLoadingPositions(false);
      }
    };
    
    loadInitialData();
    
    // Subscribe to real-time updates
    const unsubscribeAccounts = subscribeToMt5AccountUpdates(selectedUser, (updatedAccounts) => {
      setAccounts(updatedAccounts);
      setLastUpdated(new Date());
    });
    
    const unsubscribePositions = subscribeToMt5PositionUpdates(selectedUser, (updatedPositions) => {
      setPositions(updatedPositions);
      setLastUpdated(new Date());
    });
    
    return () => {
      unsubscribeAccounts();
      unsubscribePositions();
    };
  }, [selectedUser, toast]);

  // Manually refresh data
  const handleRefresh = async () => {
    setIsManualRefreshing(true);
    
    try {
      const accountsData = await fetchMt5Accounts(selectedUser);
      const positionsData = await fetchMt5Positions(selectedUser);
      
      setAccounts(accountsData);
      setPositions(positionsData);
      setLastUpdated(new Date());
      
      toast({
        title: "Data Refreshed",
        description: "MT5 data has been refreshed successfully.",
      });
    } catch (error) {
      console.error("Error refreshing data:", error);
      toast({
        title: "Refresh Failed",
        description: "Could not refresh MT5 data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsManualRefreshing(false);
    }
  };

  // Calculate summary data
  const calculateSummary = () => {
    if (accounts.length === 0) return {
      totalBalance: 0,
      totalEquity: 0,
      totalMargin: 0,
      totalProfit: 0,
      balanceChange: 0,
      equityChange: 0,
      profitChange: 0
    };

    const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0);
    const totalEquity = accounts.reduce((sum, account) => sum + account.equity, 0);
    const totalMargin = accounts.reduce((sum, account) => sum + account.margin, 0);
    const totalProfit = accounts.reduce((sum, account) => sum + account.profit, 0);

    // In a real implementation, these would be calculated from historical data
    const balanceChange = 0;
    const equityChange = 0;
    const profitChange = 0;

    return {
      totalBalance,
      totalEquity,
      totalMargin,
      totalProfit,
      balanceChange,
      equityChange,
      profitChange
    };
  };

  const summaryData = calculateSummary();

  // Format date for display
  const formatDateTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(date);
  };

  return (
    <DashboardLayout>
      {/* Dashboard Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-neutral-200 shadow-sm px-4 py-4 lg:px-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-xl font-semibold text-neutral-800">User Dashboard</h1>
            <p className="text-sm text-neutral-500 mt-1">
              Last updated: <span className="font-mono">{formatDateTime(lastUpdated)}</span>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 mt-4 lg:mt-0">
            <Link href="/broker-dashboard">
              <AnimatedButton 
                variant="outline" 
                className="flex items-center gap-1"
                animationVariant="icon-slide"
              >
                <BarChart3 size={16} />
                <span>Broker View</span>
              </AnimatedButton>
            </Link>
            <div className="relative">
              <div className="flex items-center">
                <span className="mr-2 text-sm font-medium text-neutral-700">Update:</span>
                <Select value={updateInterval} onValueChange={setUpdateInterval}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Select interval" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 seconds</SelectItem>
                    <SelectItem value="15">15 seconds</SelectItem>
                    <SelectItem value="30">30 seconds</SelectItem>
                    <SelectItem value="60">1 minute</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <AnimatedButton 
              variant="outline" 
              onClick={handleRefresh}
              disabled={isManualRefreshing}
              animationVariant="ripple"
            >
              {isManualRefreshing ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-1 text-primary" />
              )}
              Refresh
            </AnimatedButton>
            <Link href="/account-management">
              <AnimatedButton
                animationVariant="glow"
                className="relative"
              >
                <span className="mr-1">+</span>
                Add Account
              </AnimatedButton>
            </Link>
          </div>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="px-4 py-6 lg:px-6">
        {isLoading ? (
          <div className="flex items-center justify-center p-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Portfolio Summary */}
            <AccountSummary 
              totalBalance={summaryData.totalBalance}
              totalEquity={summaryData.totalEquity}
              totalMargin={summaryData.totalMargin}
              totalProfit={summaryData.totalProfit}
              balanceChange={summaryData.balanceChange}
              equityChange={summaryData.equityChange}
              profitChange={summaryData.profitChange}
            />

            {/* Active Alerts Section */}
            <ActiveAlerts />

            {/* Account Cards */}
            <h2 className="text-lg font-semibold mb-4">MT5 Accounts</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-6">
              {accounts.map(account => (
                <AccountCard 
                  key={account.accountNumber}
                  account={account}
                />
              ))}
              <AddAccountCard />
            </div>

            {/* Open Positions Table */}
            <OpenPositionsTable 
              positions={positions}
              isLoading={isLoadingPositions}
              accounts={accounts}
            />

            {/* Alert Configuration Card */}
            <AlertConfigurationCard />
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
