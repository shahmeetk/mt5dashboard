import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, LogOut, LineChart, Filter } from "lucide-react";
import { fetchMt5Accounts, fetchMt5Positions } from "@/lib/mt5-client";
import { Mt5AccountData, Mt5Position } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue
} from "@/components/ui/select";

export default function HomePage() {
  const [isLoading, setIsLoading] = useState(true);
  const [accounts, setAccounts] = useState<Mt5AccountData[]>([]);
  const [positions, setPositions] = useState<Mt5Position[]>([]);
  const [activeTab, setActiveTab] = useState("accounts");
  const [activeBroker, setActiveBroker] = useState<string | null>(null);
  const [brokers, setBrokers] = useState<string[]>([]);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user, logoutMutation } = useAuth();

  // Load accounts and positions data
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        if (user?.id) {
          const userId = user.id.toString();
          const accountsData = await fetchMt5Accounts(userId, activeBroker || undefined);
          setAccounts(accountsData);
          
          const positionsData = await fetchMt5Positions(userId, activeBroker || undefined);
          setPositions(positionsData);
          
          // Extract unique broker names
          if (!activeBroker) {
            // Get all broker names and filter out duplicates
            const brokerNames = accountsData.map(account => account.brokerName);
            const uniqueBrokers = brokerNames.filter((name, index) => 
              brokerNames.indexOf(name) === index
            );
            setBrokers(uniqueBrokers);
          }
        }
      } catch (error) {
        console.error("Error loading data:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load account data. Please try again."
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadData();
  }, [user, activeBroker, toast]);

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };
  
  // Format number for display
  const formatNumber = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
      style: 'decimal',
      useGrouping: true
    }).format(value);
  };

  // Calculate total values for all accounts or filtered by broker
  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
  const totalEquity = accounts.reduce((sum, acc) => sum + acc.equity, 0);
  const totalMargin = accounts.reduce((sum, acc) => sum + acc.margin, 0);
  const totalProfit = accounts.reduce((sum, acc) => sum + acc.profit, 0);
  const totalPositionsCount = accounts.reduce((sum, acc) => sum + acc.positions, 0);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background border-b border-neutral-200 shadow-sm px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <LineChart className="h-6 w-6 text-primary mr-2" />
            <h1 className="text-xl font-semibold">MT5 Monitor</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              onClick={() => {
                setIsLoading(true);
                // Re-fetch data
                if (user?.id) {
                  const userId = user.id.toString();
                  Promise.all([
                    fetchMt5Accounts(userId, activeBroker || undefined),
                    fetchMt5Positions(userId, activeBroker || undefined)
                  ]).then(([accountsData, positionsData]) => {
                    setAccounts(accountsData);
                    setPositions(positionsData);
                    setIsLoading(false);
                  }).catch(error => {
                    console.error("Error refreshing data:", error);
                    setIsLoading(false);
                  });
                } else {
                  setIsLoading(false);
                }
              }}
            >
              Refresh
            </Button>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              className="flex items-center gap-1"
            >
              <LogOut size={16} />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center p-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Broker Filter */}
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">
                {activeBroker ? `${activeBroker} Dashboard` : "All Brokers Dashboard"}
              </h2>
              <div className="flex items-center gap-2">
                <Select
                  value={activeBroker || "all"}
                  onValueChange={(value) => setActiveBroker(value === "all" ? null : value)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select Broker" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Brokers</SelectItem>
                    {brokers.map(broker => (
                      <SelectItem key={broker} value={broker}>{broker}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Summary Card */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Account Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr>
                        <th className="py-2 px-4 border text-left font-semibold">Balance</th>
                        <th className="py-2 px-4 border text-left font-semibold">Equity</th>
                        <th className="py-2 px-4 border text-left font-semibold">Margin</th>
                        <th className="py-2 px-4 border text-left font-semibold">PnL</th>
                        <th className="py-2 px-4 border text-left font-semibold">OpenPositions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="py-2 px-4 border text-right font-medium text-base">{formatNumber(totalBalance)}</td>
                        <td className="py-2 px-4 border text-right font-medium text-base">{formatNumber(totalEquity)}</td>
                        <td className="py-2 px-4 border text-right font-medium text-base">{formatNumber(totalMargin)}</td>
                        <td className={`py-2 px-4 border text-right font-semibold text-base ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatNumber(totalProfit)}
                        </td>
                        <td className="py-2 px-4 border text-right font-medium text-base">{totalPositionsCount}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Tabs for Accounts and Positions */}
            <Tabs defaultValue="accounts" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="accounts">Accounts</TabsTrigger>
                <TabsTrigger value="positions">Positions</TabsTrigger>
              </TabsList>
              
              <TabsContent value="accounts">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {accounts.map(account => (
                    <Card key={account.accountNumber}>
                      <CardHeader>
                        <CardTitle className="text-lg">{account.accountName}</CardTitle>
                        <p className="text-sm text-muted-foreground">{account.brokerName} - {account.accountNumber}</p>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Balance</p>
                            <p className="font-medium">{formatCurrency(account.balance)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Equity</p>
                            <p className="font-medium">{formatCurrency(account.equity)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Margin</p>
                            <p className="font-medium">{formatCurrency(account.margin)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Profit</p>
                            <p className={`font-medium ${account.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(account.profit)}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Margin Level</p>
                            <p className="font-medium">{account.marginLevel.toFixed(2)}%</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Open Positions</p>
                            <p className="font-medium">{account.positions}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                
                {accounts.length === 0 && (
                  <div className="text-center p-8 border rounded-lg">
                    <p className="text-muted-foreground">No accounts found {activeBroker ? `for ${activeBroker}` : ""}</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="positions">
                <Card>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-4 font-semibold">AccountName</th>
                            <th className="text-left p-4 font-semibold">BrokerName</th>
                            <th className="text-left p-4 font-semibold">Symbol</th>
                            <th className="text-left p-4 font-semibold">OrderType</th>
                            <th className="text-left p-4 font-semibold">Volume</th>
                            <th className="text-right p-4 font-semibold">OpenPrice</th>
                            <th className="text-right p-4 font-semibold">CurrentPrice</th>
                            <th className="text-right p-4 font-semibold">ProfitLoss</th>
                          </tr>
                        </thead>
                        <tbody>
                          {positions.map((position, index) => (
                            <tr key={index} className="border-b">
                              <td className="p-4">{position.accountName}</td>
                              <td className="p-4">
                                {accounts.find(a => a.accountNumber === position.accountNumber)?.brokerName || ""}
                              </td>
                              <td className="p-4">{position.symbol}</td>
                              <td className="p-4">
                                <span className={position.type === 'BUY' ? 'text-green-600' : 'text-red-600'}>
                                  {position.type}
                                </span>
                              </td>
                              <td className="p-4">{position.volume}</td>
                              <td className="text-right p-4">{position.openPrice.toFixed(5)}</td>
                              <td className="text-right p-4">{position.currentPrice.toFixed(5)}</td>
                              <td className={`text-right p-4 ${position.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {formatCurrency(position.profit)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      
                      {positions.length === 0 && (
                        <div className="text-center p-8">
                          <p className="text-muted-foreground">No positions found {activeBroker ? `for ${activeBroker}` : ""}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>
    </div>
  );
}