import { pgTable, text, serial, integer, boolean, timestamp, json, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  displayName: text("display_name"),
  isAdmin: boolean("is_admin").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  displayName: true,
  isAdmin: true,
  isActive: true,
});

export const mt5Accounts = pgTable("mt5_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  accountName: text("account_name").notNull(),
  accountNumber: text("account_number").notNull(),
  brokerName: text("broker_name").notNull(),
  serverName: text("server_name").notNull(),
  credentials: text("credentials").notNull(), // Encrypted investor password
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMt5AccountSchema = createInsertSchema(mt5Accounts).pick({
  accountName: true,
  accountNumber: true,
  brokerName: true,
  serverName: true,
  credentials: true,
});

export const mt5AccountAlerts = pgTable("mt5_account_alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  accountId: integer("account_id").references(() => mt5Accounts.id),
  name: text("name").notNull(),
  description: text("description"),
  alertType: text("alert_type").notNull(), // e.g., "margin_level", "capital_loss", "m2m_drop"
  threshold: real("threshold").notNull(), // e.g., 200 for 200% margin level, 20 for 20% capital loss
  isActive: boolean("is_active").default(true),
  notificationMethods: text("notification_methods").array(), // e.g., ["email", "dashboard"]
  timeWindow: integer("time_window"), // in minutes, for time-based alerts like M2M drop
  lastTriggered: timestamp("last_triggered"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMt5AccountAlertSchema = createInsertSchema(mt5AccountAlerts).pick({
  name: true,
  description: true,
  accountId: true,
  alertType: true,
  threshold: true,
  isActive: true,
  notificationMethods: true,
  timeWindow: true,
});

// Types for the MT5 account data structures (not stored in DB)
export type Mt5AccountData = {
  accountNumber: string;
  accountName: string;
  brokerName: string;
  serverName?: string; // Added serverName field
  balance: number;
  equity: number;
  margin: number;
  freeMargin: number;
  marginLevel: number;
  profit: number;
  positions: number;
  lastUpdated: string;
  status: "healthy" | "warning" | "danger";
};

export type Mt5Position = {
  accountNumber: string;
  accountName: string;
  symbol: string;
  type: "BUY" | "SELL";
  volume: number;
  openPrice: number;
  currentPrice: number;
  profit: number;
  profitPercent: number;
  ticket: number;
};

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Mt5Account = typeof mt5Accounts.$inferSelect;
export type InsertMt5Account = z.infer<typeof insertMt5AccountSchema>;
export type Mt5AccountAlert = typeof mt5AccountAlerts.$inferSelect;
export type InsertMt5AccountAlert = z.infer<typeof insertMt5AccountAlertSchema>;
